package db.migration;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.flywaydb.core.api.migration.BaseJavaMigration;
import org.flywaydb.core.api.migration.Context;

public class V3_6__InsertRandomPersons extends BaseJavaMigration 
{
	@Override
    public void migrate(Context context) throws Exception 
	{
		  Connection connection = context.getConnection();
		  
          try (PreparedStatement statement = connection.prepareStatement(                   
               "INSERT INTO PERSON (ID, FIRST_NAME, LAST_NAME) " +
               "values (5, 'Anne', 'Will');")) 
          {
              statement.execute();
          }
          
        // Create 10 random persons
      	for(int i = 1; i < 11; i++)
		{
			try (PreparedStatement statement = connection.prepareStatement(
			     String.format("INSERT INTO PERSON (ID, FIRST_NAME, LAST_NAME)" +
				               "VALUES(%d, 'Peter_%d', 'Lustig_%d')", i + 1000, i, i)))
			{
      	         statement.execute();
			}
		}
	}
}