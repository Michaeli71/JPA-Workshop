CREATE TABLE PERSON (
	id int not null primary key,
	first_name varchar(255) not null,
	last_name varchar(255) not null
);