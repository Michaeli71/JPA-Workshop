ALTER TABLE PERSON
ADD Email varchar(255);

ALTER TABLE PERSON
ADD last_modified_date timestamp;

UPDATE PERSON
SET last_modified_date=current_timestamp;

UPDATE PERSON 
SET Email=CONCAT(first_name, '_', last_name, '@specialcompany.ch');

