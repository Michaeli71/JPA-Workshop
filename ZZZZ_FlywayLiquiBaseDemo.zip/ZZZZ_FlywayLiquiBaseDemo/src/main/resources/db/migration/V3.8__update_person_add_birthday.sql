ALTER TABLE PERSON
ADD date_of_birth date;

UPDATE PERSON SET date_of_birth = '1971-03-27' WHERE ID = 1;
UPDATE PERSON SET date_of_birth = '1951-12-12' WHERE ID = 2;
UPDATE PERSON SET date_of_birth = '1971-02-07' WHERE ID = 3;
UPDATE PERSON SET date_of_birth = '2020-11-23' WHERE ID = 4;
