insert into PERSON (ID, FIRST_NAME, LAST_NAME) values (1, 'Tim', 'Bötzmeyer');
insert into PERSON (ID, FIRST_NAME, LAST_NAME) values (2, 'Tom', 'Jerry');
insert into PERSON (ID, FIRST_NAME, LAST_NAME) values (3, 'Michael', 'Inden');
insert into PERSON (ID, FIRST_NAME, LAST_NAME) values (4, 'Sophie', 'Inden');
