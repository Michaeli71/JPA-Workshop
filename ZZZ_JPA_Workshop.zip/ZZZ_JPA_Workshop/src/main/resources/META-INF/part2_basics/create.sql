CREATE TABLE Persons2 (PersonID int, LastName varchar(255), FirstName varchar(255),    Address varchar(255),  City varchar(255))
         
CREATE TABLE Movie2 (id bigint not null,  releaseDate date, rented boolean not null,        title varchar(255),        primary key (id)    )


create table SomeOther (       id bigint not null,         releaseDate date,    rented boolean not null,        title varchar(255),        primary key (id)    )