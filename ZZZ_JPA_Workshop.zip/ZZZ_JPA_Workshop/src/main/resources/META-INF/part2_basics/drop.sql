DROP TABLE Persons2 IF EXISTS;
         
DROP table Movie2 IF EXISTS;

DROP table SomeOther IF EXISTS;