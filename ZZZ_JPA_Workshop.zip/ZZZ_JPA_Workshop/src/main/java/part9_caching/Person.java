package part9_caching;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * Beispielklasse zur Modellierung einer Person mit JPA-Annotations 
 * 
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden
 */
@Entity
@Table(name = "PersonenWithCaching")
@NamedQuery(query = "SELECT p FROM Person p WHERE p.birthday > :birthday", name = "findPersonsBornAfter")
@Cacheable
public class Person implements Serializable
{
    @Id
    @GeneratedValue
    private long id;

    @Column(name = "Vorname")
    private String firstName;

    @Column(name = "Name")
    private String lastName;

    @Column(name = "Geburtstag")
    private Date birthday;    

    @Column(name = "Alter")
    private int age;
    
    private Person()
    {
    }
    
    public Person(String firstName, String lastName, Date birthday)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = birthday;
        final ZonedDateTime zdt = ZonedDateTime.ofInstant(birthday.toInstant(), ZoneId.systemDefault());
        this.age = (int) (ChronoUnit.YEARS.between(zdt.toLocalDate(), LocalDate.now()));
    }
    
    public long getId()
    {
        return id;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public Date getBirthday()
    {
        return new Date(birthday.getTime());
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public void setId(long id)
    {
        this.id = id;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public void setBirthday(Date birthday)
    {
        this.birthday = birthday;
    }

    public int getAge()
    {
    	return age;
    }

    public void setAge(int age)
    {    	
    	this.age = age;
    }
    
    @Override
    public String toString()
    {
        return "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", birthday=" + birthday + ", age=" + age + "]";
    }
}
