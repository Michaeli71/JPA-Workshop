package part9_caching;

import javax.persistence.Cacheable;
import javax.persistence.Entity;

@Cacheable(false)
@Entity
public class MyNonCacheableEntityClass extends MyCacheableEntityClass 
{
    /// ...
}