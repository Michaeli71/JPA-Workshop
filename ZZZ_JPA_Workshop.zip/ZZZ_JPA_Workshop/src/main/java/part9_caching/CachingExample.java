package part9_caching;

import javax.persistence.Cache;
import javax.persistence.EntityManager;

import utils.DbBase;

public class CachingExample extends DbBase
{
	public static void main(final String[] args) 
	{
		new CachingExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-CACHING";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) 
	{
		Cache cache = getEntityManagerFactory().getCache();

		if (cache.contains(Person.class, 4711)) {
			// load it as we don't hit the DB
			cache.evict(Person.class, 4711); // manually evict person form the second-level cache
		} else {
			System.out.println("No Person with id 4711 in cache");
		}

		// Remove a specific entity object from the shared cache:
		cache.evict(Person.class, Long.valueOf(4711L));

		// Remove all the instances of a specific class from the cache:
		cache.evict(Person.class);

		// Clear the shared cache by removing all the cached entity objects:
		cache.evictAll();	
	}
}

