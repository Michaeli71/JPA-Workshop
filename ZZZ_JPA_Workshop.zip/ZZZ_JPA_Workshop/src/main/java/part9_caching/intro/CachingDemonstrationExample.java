package part9_caching.intro;

import javax.persistence.Cache;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class CachingDemonstrationExample {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("java-profi-PU-CACHING");
		EntityManager em = emf.createEntityManager();

		EntityTransaction txn = em.getTransaction();
		txn.begin();

		Animal animal1 = new Animal();
		Animal animal2 = new Animal();

		Bike bike = new Bike();

		Computer computer = new Computer();

		em.persist(animal1);
		em.persist(animal2);
		em.persist(bike);
		em.persist(computer);

		int idAnimal = animal1.getIdAnimal();
		int idBike = bike.getIdBike();
		int idComputer = computer.getIdComputer();

		txn.commit();
		txn.begin();

		Cache cache = emf.getCache();

		System.out.println("Animal in Cache: " + cache.contains(Animal.class, idAnimal));
		System.out.println("Bike in Cache : " + cache.contains(Bike.class, idBike));
		System.out.println("Computer in Cache : " + cache.contains(Computer.class, idComputer));
		
		/*
		int size = CacheManager.ALL_CACHE_MANAGERS.get(0)
	    		  .getCache("y_caching.intro.Animal").getSize();
	    System.out.println("Size" + size);
	    */
		
		cache.evictAll();

		System.out.println("Animal in Cache after evict: " + cache.contains(Animal.class, idAnimal));
		System.out.println("Bike in Cache after evict: " + cache.contains(Bike.class, idBike));
		System.out.println("Computer in Cache after evict: " + cache.contains(Computer.class, idComputer));

		/*
		size = CacheManager.ALL_CACHE_MANAGERS.get(0)
	    		  .getCache("y_caching.intro.Animal").getSize();
	    System.out.println("Size" + size);
	    */
	    
		txn.commit();
		em.close();
		emf.close();
	}

}
