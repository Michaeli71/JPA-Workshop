package part9_caching;

import java.util.Date;
import java.util.List;

import javax.persistence.Cache;
import javax.persistence.EntityManager;

import net.sf.ehcache.CacheManager;
import utils.DbBase;

/**
 * Beispiel zur Demonstration der Kurzvarainte beim Formulieren von Queries
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class PersonCachingExample extends DbBase
{
	public static void main(final String[] args) 
	{
		new PersonCachingExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-CACHING";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
		createPersons(entityManager);

		final String shortQuery = "FROM Person";
		final List<Person> result1 = entityManager.createQuery(shortQuery, Person.class).getResultList();
		result1.forEach(System.out::println);

		final String normalQuery = "SELECT p FROM Person p";
		final List<Person> result2 = entityManager.createQuery(normalQuery, Person.class).getResultList();
		result2.forEach(System.out::println);

		var person = entityManager.find(Person.class, 1L);
		System.out.println(person);
		long pid = person.getId();
		System.out.println("Person Id: " + pid);		
	}

	// ACHTUNG: Muss nach Transaktionsenede geschehen, weil sonst natürlich noch nicht im 2nd Level Cache sichtbar!
	@Override
	protected void secondAction(EntityManager entityManager)
	{
		accessCache(entityManager);
	}


	private static void accessCache(final EntityManager entityManager) {

		Cache cache = entityManager.getEntityManagerFactory().getCache();
		System.out.println("Cache size: " + getCacheSize(Person.class));

		if (cache.contains(Person.class, 1L)) {
			if (cache.contains(Person.class, 2L)) {
				// manually evict user form the second-level cache
				cache.evict(Person.class, 2L); 
			} else {
				System.out.println("No Person with id 2 in cache");
			}
		} else {
			System.out.println("No Person with id 1 in cache");
		}

		System.out.println("Size after 1: " + getCacheSize(Person.class));

		// manually evict user form the second-level cache
		cache.evict(Person.class, 1L); 					
		System.out.println("Size after 2: " + getCacheSize(Person.class));

		// Remove all the instances of a specific class from the cache:
		cache.evict(Person.class);		
		System.out.println("Size after 3: " + getCacheSize(Person.class));
		
		// Clear the shared cache by removing all the cached entity objects:
		cache.evictAll();
		System.out.println("Size after 4: " + getCacheSize(Person.class));
	}

	private static int getCacheSize(Class<?> clazz) 
	{
		return CacheManager.ALL_CACHE_MANAGERS.get(0).getCache(clazz.getName()).getSize();
	}

	private static void createPersons(final EntityManager entityManager) {
		final Person micha = new Person("Micha-JPQL", "Inden", new Date(71, 1, 7));
		final Person tim = new Person("Tim-JPQL", "Inden", new Date(71, 2, 27));
		final Person werner = new Person("Werner-JPQL", "Inden", new Date(40, 0, 31));
		final Person barbara = new Person("Barbara-JPQL", "Inden", new Date(73, 2, 24));

		entityManager.persist(micha);
		entityManager.persist(werner);
		entityManager.persist(tim);
		entityManager.persist(barbara);
	}
}
