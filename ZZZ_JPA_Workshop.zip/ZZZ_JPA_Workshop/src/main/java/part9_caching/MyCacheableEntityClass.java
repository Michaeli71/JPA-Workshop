package part9_caching;

import javax.persistence.Cacheable;
import javax.persistence.Entity;

@Cacheable // or @Cacheable(true)
@Entity
public class MyCacheableEntityClass 
{
    // ...
}