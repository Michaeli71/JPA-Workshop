package part7_dao_repositories;

import java.util.List;
import java.util.Optional;

public interface Dao<T> 
{
	T save(T t);

	Optional<T> get(long id);
	List<T> getAll();

	void delete(T t);
}
