package part7_dao_repositories;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration von Zugriffen auf die Datenbank mithilfe eines DAO
 * und JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2106 by Michael Inden
 */
public final class GenericDaoExample extends DbBase
{
	public static void main(final String[] args) throws Exception {
		new GenericDaoExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-DAO";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
        // DAO erzeugen
        final GenericDAO<Person, Long> dao = new GenericDAO<>(entityManager, Person.class);

        // Einfügeoperationen ausführen und das Resultat prüfen
        final Person michael = new Person("Micha-DAO", "Inden", new Date(71, 1, 7));
        final Person michael2 = new Person("Micha-DAO", "Inden", new Date(71, 1, 7));
        final Person werner = new Person("Werner-DAO", "Inden", new Date(40, 0, 31));

        final long michaelId = dao.save(michael).getId();
        final long michaelId2 = dao.save(michael2).getId();
        final long wernerId = dao.save(werner).getId();

        final List<Person> persons2 = dao.findAll();
        persons2.forEach(System.out::println);

        // Änderungen ausführen und das Resultat prüfen
        dao.deleteById(michaelId);
        werner.setFirstName("Dr. h.c. Werner");

        final List<Person> persons = dao.findAll();
        persons.forEach(System.out::println);
    }
}
