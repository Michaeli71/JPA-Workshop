package part7_dao_repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 * Beispielklasse eines Data Access Objects (DAOs) zum Zugriff auf Personen-Datensaetze
 * 
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden 
 */
public final class PersonDAO
{
    private final EntityManager entityManager;

    PersonDAO(final EntityManager entityManager)
    {
        this.entityManager = entityManager;
    }

    // C -- CREATE
    public long createPerson(final Person newPerson)
    {        
        entityManager.persist(newPerson);
        return newPerson.getId();
    }

    // R -- READ
    public Person findPersonById(final long id)
    {
        return entityManager.find(Person.class, id);
    }
    
    // R -- READ
    public List<Person> findAllPersons()
    {
       final TypedQuery<Person> query = entityManager.createQuery("FROM Person", 
                                                                  Person.class);
       return query.getResultList(); 
    }
      
    // U -- UPDATE
    public void updatePersonFrom(final long destId, final Person otherPerson)
    {
        final Person personInDb = findPersonById(destId);  
        if (personInDb != null)
        {
        	personInDb.setFirstName(otherPerson.getFirstName());
        	personInDb.setLastName(otherPerson.getLastName());
        	personInDb.setBirthday(otherPerson.getBirthday());
        }
    }

    // D -- DELETE
    public void deletePersonById(final long id)
    {
        final Person personInDb = findPersonById(id);  
        if (personInDb != null)
        {
        	entityManager.remove(personInDb);
        }
    }
}
