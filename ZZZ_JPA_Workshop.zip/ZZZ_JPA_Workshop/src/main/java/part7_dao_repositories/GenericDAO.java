package part7_dao_repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 * Beispielklasse eines Data Access Objects (DAOs) zum Zugriff auf Personen-Datensaetze
 * 
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden 
 */
public final class GenericDAO<T, K>
{
    private final EntityManager entityManager;
    private final Class<T> clazz;

    GenericDAO(final EntityManager entityManager, Class<T> clazz)
    {
        this.entityManager = entityManager;
        this.clazz = clazz;
    }

    // C -- CREATE
    public T save(final T newObject)
    {        
        entityManager.persist(newObject);
        return newObject;
    }

    // R -- READ
    public T findById(final K id)
    {
        return entityManager.find(clazz, id);
    }
    
    // R -- READ
    public List<T> findAll()
    {
       final TypedQuery<T> query = entityManager.createQuery("FROM " + clazz.getSimpleName(), 
    		                                                 clazz);
       return query.getResultList(); 
    }
      
    // U -- UPDATE
    // ...

    // D -- DELETE
    public void deleteById(final K id)
    {
        final T objectInDb = findById(id);  
        if (objectInDb != null)
        {
        	entityManager.remove(objectInDb);
        }
    }
}
