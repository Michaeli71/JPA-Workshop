package part7_dao_repositories;

import java.util.List;

public interface IPersonDAO 
{
	// CRUD-Funktionalität
	public List<Person> getAllPersons() throws DataAccessException;

	public long addPerson(final Person person) throws DataAccessException;

	public void updateFromOther(final long personId, final Person otherPerson) throws DataAccessException;

	public void removePerson(final long personId) throws DataAccessException;

	// komplexere fachliche oder Verarbeitungsfunktionalität
	public int removePersonsOlderThan(final int age) throws DataAccessException;
}

class DataAccessException extends Exception
{
}