package part7_dao_repositories;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration von Zugriffen auf die Datenbank mithilfe eines DAO
 * und JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2106 by Michael Inden
 */
public final class PersonDaoExample extends DbBase
{
	public static void main(final String[] args) throws Exception {
		new PersonDaoExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-DAO";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
        // DAO erzeugen
		final PersonDAO dao = new PersonDAO(entityManager);
	
		// Einfügeoperationen ausführen und das Resultat prüfen
		final Person michael = new Person("Micha-DAO", "Inden", new Date(71, 1, 7));
		final Person michael2 = new Person("Micha-DAO", "Inden", new Date(71, 1, 7));
		final Person werner = new Person("Werner-DAO", "Inden", new Date(40, 0, 31));
	
		final long michaelId = dao.createPerson(michael);
		final long michaelId2 = dao.createPerson(michael2);
		final long wernerId = dao.createPerson(werner);
	
		final List<Person> persons2 = dao.findAllPersons();
		persons2.forEach(System.out::println);
	
		// Änderungen ausführen und das Resultat prüfen
		dao.deletePersonById(michaelId);
		werner.setFirstName("Dr. h.c. Werner");
	
		final List<Person> persons = dao.findAllPersons();
		persons.forEach(System.out::println);
	}
}
