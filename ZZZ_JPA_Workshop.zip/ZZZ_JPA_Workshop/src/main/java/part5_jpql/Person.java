package part5_jpql;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * Beispielklasse zur Modellierung einer Person mit JPA-Annotations 
 * 
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden
 */
@Entity
@Table(name = "PersonenJPQL")
@NamedQuery(query = "SELECT p FROM Person p WHERE p.birthday > :birthday", 
            name = "findPersonsBornAfter")
public class Person implements Serializable
{
    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "Vorname")
    private String firstName;

    @Column(name = "Name")
    private String lastName;

    @Column(name = "Geburtstag")
    private LocalDate birthday;    

    @Column(name = "Alter")
    private int age;
    
    private Person()
    {
    }
    
    public Person(String firstName, String lastName, LocalDate birthday)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = birthday;
        this.age = (int) (ChronoUnit.YEARS.between(birthday, LocalDate.now()));
    }
    
    public long getId()
    {
        return id;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public LocalDate getBirthday()
    {
        return birthday;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public void setId(long id)
    {
        this.id = id;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public void setBirthday(LocalDate birthday)
    {
        this.birthday = birthday;
    }

    public int getAge()
    {
    	return age;
    }

    public void setAge(int age)
    {    	
    	this.age = age;
    }
    
    @Override
    public String toString()
    {
        return "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", birthday=" + birthday + ", age=" + age + "]";
    }
}
