package part5_jpql.intro;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import part5_jpql.Person;
import utils.DbBase;

/**
 * Beispiel zur Demonstration verschiederer Aktionen mit JPQL
 *
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden 
 */
public final class PersonJpqlQueriesExample extends DbBase
{
    public static void main(final String[] args) 
    {
    	new PersonJpqlQueriesExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-JPQL";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) 
	{
        createPersons(entityManager);
        performQueries(entityManager);
    }

    private static void performQueries(final EntityManager entityManager)
    {
        // Einfache Abfrage
		final String personsQuery = "SELECT p FROM Person p";
		final TypedQuery<Person> persons = entityManager.createQuery(personsQuery, Person.class);
		final List<Person> allPersons = persons.getResultList();
		
		// Zugriffe auf einzelne Attribute
		final String firstNamesQuery = "SELECT p.firstName FROM Person p " + "ORDER BY p.firstName";
		final TypedQuery<String> firstNames = entityManager.createQuery(firstNamesQuery, String.class);
		final List<String> sortedFirstNames = firstNames.getResultList();



        // Ergebnisse ausgeben
        System.out.println(personsQuery + ":\n" + allPersons);
        System.out.println(firstNamesQuery + ":\n" + sortedFirstNames);
    }

	private static void performNamedQuery(final EntityManager entityManager)
	{
	    final Query namedQuery = entityManager.createNamedQuery("findPersonsBornAfter");
	    namedQuery.setParameter("birthday", LocalDate.of(1977, 1, 1));
	
	    System.out.println("Named Query");
	    final List<Person> result = namedQuery.getResultList();
	    result.forEach(System.out::println);
	}

    private static void createPersons(final EntityManager entityManager)
    {
        final Person micha = new Person("Micha-JPQL", "Inden", LocalDate.of(1971, 2, 7));
        final Person tim = new Person("Tim-JPQL", "Bötz", LocalDate.of(1984, 3, 27));
        final Person tom = new Person("Tom-JPQL", "Meyer", LocalDate.of(1955, 1, 31));

        entityManager.persist(micha);
        entityManager.persist(tim);
        entityManager.persist(tom);
    }


}
