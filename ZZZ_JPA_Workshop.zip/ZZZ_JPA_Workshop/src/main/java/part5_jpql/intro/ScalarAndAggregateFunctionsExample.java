package part5_jpql.intro;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import part5_jpql.Person;
import utils.DbBase;

public class ScalarAndAggregateFunctionsExample extends DbBase
{
	public static void main(String[] args) {
		new ScalarAndAggregateFunctionsExample().dbAcessAlgorithm();
	}
	
	@Override
	protected String getPuName() {
		return "java-profi-PU-JPQL";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
		createPersons(entityManager);
        
		// Scalar function
		Query query = entityManager.createQuery("SELECT UPPER(p.lastName) from Person p");
		List<String> list = query.getResultList();
		list.forEach(lastName -> System.out.println("NAME: " + lastName));

		// Aggregate function
		Query query1 = entityManager.createQuery("SELECT MAX(p.age) from Person p");
		Integer result = (Integer)query1.getSingleResult();
		System.out.println("Max Age: " + result);
		
		
		// Berechnungen in Queries
		final String personCountQuery = "SELECT COUNT(p) FROM Person p";
		final Query countQuery = entityManager.createQuery(personCountQuery);
		final Object count = countQuery.getSingleResult();
		
		final String avgAgeQuery = "SELECT AVG(p.age) FROM Person p";
		final TypedQuery<Double> avgQuery = entityManager.createQuery(avgAgeQuery, Double.class);
		final Double avgAge = avgQuery.getSingleResult();
        System.out.println("\nCount: " + count + " / type: " + count.getClass());
        System.out.println("Avg Age: " + avgAge);
	}
	
    private static void createPersons(final EntityManager entityManager)
    {
        final Person micha = new Person("Micha-JPQL", "Inden", LocalDate.of(1971, 2, 7));
        final Person tim = new Person("Tim-JPQL", "Bötz", LocalDate.of(1984, 3, 27));
        final Person tom = new Person("Tom-JPQL", "Meyer", LocalDate.of(1955, 1, 31));
        final Person werner = new Person("Werner-JPQL", "Inden", LocalDate.of(1940, 1, 31));
        final Person barbara = new Person("Barbara-JPQL", "Inden", LocalDate.of(1973, 3, 24));

        entityManager.persist(micha);
        entityManager.persist(werner);
        entityManager.persist(tim);
        entityManager.persist(tom);
        entityManager.persist(barbara);
    }


}