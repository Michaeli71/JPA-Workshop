package part5_jpql.intro;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import part5_jpql.Person;
import utils.DbBase;

/**
 * Beispiel zur Demonstration von Paramtrierungen in JPQL-Queries
 * 
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden 
 */
public final class ParametrizedQueriesExample extends DbBase
{
    public static void main(final String[] args) 
    {
        new ParametrizedQueriesExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-JPQL";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) 
	{
        createPersons(entityManager);

        final int minAge = 40;
        final int maxAge = 50;

		final String jpql1 = "SELECT person FROM Person person " + "WHERE person.age >= ? AND person.age < ?";
		final TypedQuery<Person> typedQuery1 = entityManager.createQuery(jpql1, Person.class);
		typedQuery1.setParameter(1, minAge);
		typedQuery1.setParameter(2, maxAge);
		typedQuery1.getResultList().forEach(System.out::println);
		
		final String jpql2 = "SELECT person FROM Person person "
		                     + "WHERE person.age >= :minAge AND person.age < :maxAge";
		final TypedQuery<Person> typedQuery2 = entityManager.createQuery(jpql2, Person.class);
		typedQuery2.setParameter("minAge", minAge);
		typedQuery2.setParameter("maxAge", maxAge);
		typedQuery2.getResultList().forEach(System.out::println);
    }

    private static void createPersons(final EntityManager entityManager)
    {
        final Person micha = new Person("Micha-JPQL", "Inden", LocalDate.of(1971, 2, 7));
        final Person tim = new Person("Tim-JPQL", "Bötz", LocalDate.of(1984, 3, 27));
        final Person tom = new Person("Tom-JPQL", "Meyer", LocalDate.of(1955, 1, 31));
        final Person werner = new Person("Werner-JPQL", "Inden", LocalDate.of(1940, 1, 31));
        final Person barbara = new Person("Barbara-JPQL", "Inden", LocalDate.of(1973, 3, 24));

        entityManager.persist(micha);
        entityManager.persist(werner);
        entityManager.persist(tim);
        entityManager.persist(tom);
        entityManager.persist(barbara);
    }
}
