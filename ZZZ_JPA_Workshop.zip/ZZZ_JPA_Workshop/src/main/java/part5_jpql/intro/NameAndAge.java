package part5_jpql.intro;

/**
 * Beispielklasse zur Modellierung eines Paars von Namen und Alter für eine Ergebnismenge 
 * 
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden
 */
public class NameAndAge
{
	private final String name;
	private final int age;
	
	public NameAndAge(final String name, final int age) 
	{
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() 
	{
		return "NameAndAge [name=" + name + ", age=" + age + "]";
	}
}

