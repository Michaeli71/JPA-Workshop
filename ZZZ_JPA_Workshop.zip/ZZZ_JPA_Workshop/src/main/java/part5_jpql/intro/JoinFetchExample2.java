package part5_jpql.intro;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import part5_jpql.Task;
import part5_jpql.WorkEmployee;
import utils.DbBase;

// Basiert auf: https://www.logicbig.com/tutorials/java-ee-tutorial/jpa/fetch-join.html
public final class JoinFetchExample2 extends DbBase {
	public static void main(final String[] args) {
		new JoinFetchExample2().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-JPQL";
	}

	@Override
	protected void executeStatements(final EntityManager entityManager) {
		persistEmployees(entityManager);
		entityManager.flush();
		entityManager.clear();
	}

	@Override
	protected void secondAction(final EntityManager entityManager) {
		executeQuery(entityManager);
	}
	
	public static void persistEmployees(final EntityManager entityManager) {
		Task task1 = new Task("Coding", "Denise");
		Task task2 = new Task("Refactoring", "Rose");
		Task task3 = new Task("Designing", "Denise");
		Task task4 = new Task("Documentation", "Mike");

		WorkEmployee employee1 = WorkEmployee.create("Diana", task1, task3);
		WorkEmployee employee2 = WorkEmployee.create("Mike", task2, task4);
		WorkEmployee employee3 = WorkEmployee.create("Tim", task3, task4);
		WorkEmployee employee4 = WorkEmployee.create("Jack");

		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		entityManager.persist(employee4);

		System.out.println("-- Employees persisted --");
		System.out.println(employee1);
		System.out.println(employee2);
		System.out.println(employee3);
		System.out.println(employee4);
	}

	private static void executeQuery(final EntityManager entityManager) {
		System.out.println("-- executing query --");
		Query query = entityManager.createQuery("SELECT DISTINCT e FROM WorkEmployee e INNER JOIN FETCH e.tasks t");
		List<WorkEmployee> resultList = query.getResultList();
		
		for (WorkEmployee employee : resultList) {
			System.out.println(employee.getName() + " - " + employee.getTasks());
		}
	}
}
