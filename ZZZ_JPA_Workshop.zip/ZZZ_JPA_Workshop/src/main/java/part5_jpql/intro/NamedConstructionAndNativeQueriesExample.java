package part5_jpql.intro;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import part5_jpql.Person;
import utils.DbBase;

/**
 * Beispiel zur Demonstration von Objekterzeugungs-Queries mit JPQL
 * 
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden 
 */
public final class NamedConstructionAndNativeQueriesExample extends DbBase
{
    public static void main(final String[] args) throws Exception
    {
        new NamedConstructionAndNativeQueriesExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-JPQL";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) 
	{
        createPersons(entityManager);

        performObjCreateQuery(entityManager);
        performNativeQuery(entityManager);
    }



    private static void performObjCreateQuery(final EntityManager entityManager)
    {
		final String createObjJPQL = "SELECT NEW part5_jpql.intro.NameAndAge"
		                             + "(p.firstName, p.age) FROM Person p";
		final TypedQuery<NameAndAge> query = entityManager.createQuery(createObjJPQL, NameAndAge.class);

        System.out.println("\nObj Create Query");
        final List<NameAndAge> result = query.getResultList();
        result.forEach(System.out::println);
    }

	private static void performNativeQuery(final EntityManager entityManager)
	{
	    final String sqlString = "SELECT VORNAME, NAME FROM PersonenJPQL";
	    final Query nativeQuery = entityManager.createNativeQuery(sqlString);
	
	    System.out.println("\nNative Query");
	    final List<Object[]> rows = nativeQuery.getResultList();
	    rows.forEach(row -> System.out.println(Arrays.toString(row)));
	}

    private static void createPersons(final EntityManager entityManager)
    {
        final Person micha = new Person("Micha-JPQL", "Inden", LocalDate.of(1971, 2, 7));
        final Person tim = new Person("Tim-JPQL", "Bötz", LocalDate.of(1984, 3, 27));
        final Person tom = new Person("Tom-JPQL", "Meyer", LocalDate.of(1955, 1, 31));
        final Person werner = new Person("Werner-JPQL", "Inden", LocalDate.of(1940, 1, 31));
        final Person barbara = new Person("Barbara-JPQL", "Inden", LocalDate.of(1973, 3, 24));

        entityManager.persist(micha);
        entityManager.persist(werner);
        entityManager.persist(tim);
        entityManager.persist(tom);
        entityManager.persist(barbara);
    }

}
