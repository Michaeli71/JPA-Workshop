package part5_jpql.intro;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import part5_jpql.Person;
import utils.DbBase;

/**
 * Beispiel zur Demonstration der Kurzvarainte beim Formulieren von Queries
 *  
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden
 */
public final class PersonShortQueryExample extends DbBase
{
    public static void main(final String[] args) throws Exception
    {
    	new PersonShortQueryExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-JPQL";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) 
	{
	    createPersons(entityManager);
	
	    final String shortQuery = "FROM Person";
	    final List<Person> result1 = entityManager.createQuery(shortQuery, Person.class).getResultList();
	    result1.forEach(System.out::println);
	
	    final String normalQuery = "SELECT p FROM Person p";
	    final List<Person> result2 = entityManager.createQuery(normalQuery, Person.class).getResultList();
	    result2.forEach(System.out::println);
	    
	    Query query = entityManager.createQuery("SELECT p FROM Person p");
	    List resultList = query.getResultList();
	    resultList.forEach(System.out::println);
	}

    private static void createPersons(final EntityManager entityManager)
    {
        final Person micha = new Person("Micha-JPQL", "Inden", LocalDate.of(1971, 2, 7));
        final Person tim = new Person("Tim-JPQL", "Bötz", LocalDate.of(84, 3, 27));
        final Person tom = new Person("Tom-JPQL", "Meyer", LocalDate.of(55, 2, 31));
        final Person werner = new Person("Werner-JPQL", "Inden", LocalDate.of(40, 1, 31));
        final Person barbara = new Person("Barbara-JPQL", "Inden", LocalDate.of(73, 3, 24));

        entityManager.persist(micha);
        entityManager.persist(werner);
        entityManager.persist(tim);
        entityManager.persist(tom);
        entityManager.persist(barbara);
    }
}
