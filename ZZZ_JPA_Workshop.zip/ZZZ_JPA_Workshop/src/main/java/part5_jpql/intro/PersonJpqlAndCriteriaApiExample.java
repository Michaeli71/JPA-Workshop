package part5_jpql.intro;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import part5_jpql.Person;
import utils.DbBase;

/**
 * Beispiel zur Demonstration von Abfragen mit dem Criteria API
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class PersonJpqlAndCriteriaApiExample extends DbBase
{
    public static void main(final String[] args)  
    {
        new PersonJpqlAndCriteriaApiExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-JPQL";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) 
	{
        createPersons(entityManager);

        calcAvgAge(entityManager);
        personsWithinAgeRange(entityManager, 40, 50);
    }

	private static void calcAvgAge(final EntityManager entityManager)
	{
	    final String avgAgeJPQL = "SELECT AVG(person.age) FROM Person person";
	    final TypedQuery<Double> query1 = entityManager.createQuery(avgAgeJPQL, Double.class);
	
	    final CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
	    final CriteriaQuery<Double> criteriaQuery = criteriaBuilder.createQuery(Double.class);
	    final Root<Person> person = criteriaQuery.from(Person.class);
	    criteriaQuery.select(criteriaBuilder.avg(person.get("age")));
	    final TypedQuery<Double> query2 = entityManager.createQuery(criteriaQuery);
	
	    final Double avgAge1 = query1.getSingleResult();
	    final Double avgAge2 = query2.getSingleResult();
	    System.out.println("\nAvg Age 1: " + avgAge1 + " / Age 2: " + avgAge2);
	}

	private static void personsWithinAgeRange(final EntityManager entityManager, final int minAge, final int maxAge)
	{
	    final String selectJPQL = "SELECT person FROM Person person "
	                              + "WHERE person.age >= :minAge AND person.age < :maxAge";
	    final TypedQuery<Person> typedQuery1 = entityManager.createQuery(selectJPQL, Person.class);
	    typedQuery1.setParameter("minAge", minAge);
	    typedQuery1.setParameter("maxAge", maxAge);
	
	    final CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
	    final CriteriaQuery<Person> criteriaQuery = criteriaBuilder.createQuery(Person.class);
	    final Root<Person> person = criteriaQuery.from(Person.class);
	    final Path<Integer> age = person.get("age");
	    criteriaQuery.where(criteriaBuilder.and(criteriaBuilder.greaterThanOrEqualTo(age, minAge),
	                                            criteriaBuilder.lessThan(age, maxAge)));
	    final TypedQuery<Person> typedQuery2 = entityManager.createQuery(criteriaQuery);
	
	    final List<Person> results1 = typedQuery1.getResultList();
	    final List<Person> results2 = typedQuery2.getResultList();
	    System.out.println("Results1: " + results1);
	    System.out.println("Results2: " + results2);
	}
	
    private static void createPersons(final EntityManager entityManager)
    {
        final Person micha = new Person("Micha-JPQL", "Inden", LocalDate.of(1971, 2, 7));
        final Person tim = new Person("Tim-JPQL", "Bötz", LocalDate.of(84, 3, 27));
        final Person tom = new Person("Tom-JPQL", "Meyer", LocalDate.of(55, 2, 31));
        final Person werner = new Person("Werner-JPQL", "Inden", LocalDate.of(40, 1, 31));
        final Person barbara = new Person("Barbara-JPQL", "Inden", LocalDate.of(73, 3, 24));

        entityManager.persist(micha);
        entityManager.persist(werner);
        entityManager.persist(tim);
        entityManager.persist(tom);
        entityManager.persist(barbara);
    }
}
