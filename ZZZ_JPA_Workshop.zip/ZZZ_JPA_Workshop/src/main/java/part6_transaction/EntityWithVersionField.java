package part6_transaction;

import javax.persistence.Entity;
import javax.persistence.Version;

@Entity
public class EntityWithVersionField 
{
	@Version
	long version;
}