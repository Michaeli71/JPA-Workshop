package a_part_6_7.exercises;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import a_part_6_7.Person;
import utils.DbBase;

/**
 * Beispiel zur Demonstration einfacher Zugriffe auf die Datenbank mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class PersonDbAccesssWithoutDaoExample extends DbBase
{
	public static void main(final String[] args) {
		new PersonDbAccesssWithoutDaoExample().dbAcessAlgorithm();
	}


	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-6-7-EXERCISES";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
		final Person michael = new Person("Micha-DAO", "Inden", LocalDate.of(1971, 2, 7));
		final Person werner = new Person("Werner-DAO", "Inden", LocalDate.of(1940, 1, 31));
		final Person tim = new Person("Tim-DAO", "Bötz", LocalDate.of(1971, 3, 27));

		// $\mbox{\bfseries CREATE }$
		entityManager.persist(michael);
		entityManager.persist(werner);
		entityManager.persist(tim);

		// $\mbox{\bfseries READ }$
		final Long id = werner.getId();
		final Person wernerFromDb = entityManager.find(Person.class, id);

		// $\mbox{\bfseries UPDATE }$
		wernerFromDb.setFirstName("Dr. h.c. Werner");

		// $\mbox{\bfseries DELETE }$
		entityManager.remove(tim);

		printAllPersons(entityManager);	
		
		performRefresh(entityManager);	
	}

	private static void performRefresh(final EntityManager entityManager) {
		final Person michael = entityManager.find(Person.class, 1L);
		System.out.println("AFTER LOAD: " + michael);
		
		// $\mbox{\bfseries REFRESH }$
		michael.setFirstName("MICHAIL");
		michael.setLastName("INDIEN");
		System.out.println("AFTER MODIFIY: " + michael);
		
		// ACHTUNG: Scheinbar harmlos, aber gefährliche Zeile!!!
		//printAllPersons(entityManager); // ACHTUNG: Das triggert Update!!!

		// $\mbox{\bfseries REFRESH }$
		entityManager.refresh(michael);			
		System.out.println("--- AFTER REFRESH: " + michael);
		printAllPersons(entityManager);
	}

	private static void printAllPersons(final EntityManager entityManager) {
		final String jpql = "SELECT person FROM Person person";
		final TypedQuery<Person> typedQuery = entityManager.createQuery(jpql, Person.class);
		typedQuery.getResultList().forEach(System.out::println);
	}
}
