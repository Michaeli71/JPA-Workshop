package a_part_6_7;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Beispielklasse zur Modellierung einer Person mit JPA-Annotations 
 * 
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden
 */
@Entity
@Table(name = "PersonenJPA_DAO")
public class Person implements Serializable
{
    private Long id;
    private String  firstName;
    private String  lastName;
    private LocalDate birthday;

    private Person()
    {
    }
    
    public Person(String firstName, String lastName, LocalDate birthday)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = birthday;
    }
    
    @Id
    @GeneratedValue
    public Long getId()
    {
        return id;
    }

    @Column(name = "Vorname")
    public String getFirstName()
    {
        return firstName;
    }

    @Column(name = "Name")
    public String getLastName()
    {
        return lastName;
    }

    @Column(name = "Geburtstag")
    public LocalDate getBirthday()
    {
        return birthday;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public void setBirthday(LocalDate birthday)
    {
        this.birthday = birthday;
    }

    @Override
    public String toString()
    {
        return "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", birthday=" + birthday + "]";
    }
}
