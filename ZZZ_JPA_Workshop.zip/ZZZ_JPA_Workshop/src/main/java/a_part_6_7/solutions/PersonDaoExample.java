package a_part_6_7.solutions;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;

import a_part_6_7.Person;
import utils.DbBase;

/**
 * Beispiel zur Demonstration von Zugriffen auf die Datenbank mithilfe eines DAO
 * und JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2106 by Michael Inden
 */
public final class PersonDaoExample extends DbBase 
{
	
	public static void main(final String[] args) {
		new PersonDaoExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-6-7-SOLUTIONS";
	}

	@Override
	protected void executeStatements(final EntityManager entityManager) 
	{
		// DAO erzeugen
		final PersonDAO dao = new PersonDAO(entityManager);
	
		// Einfügeoperationen ausführen und das Resultat prüfen
		final Person michael = new Person("Micha-DAO", "Inden", LocalDate.of(1971, 2, 7));
		final Person werner = new Person("Werner-DAO", "Inden", LocalDate.of(1940, 1, 31));
		final Person tim = new Person("Tim-DAO", "Bötz", LocalDate.of(1971, 3, 27));
	
		// $\mbox{\bfseries CREATE }$
		final long michaelId = dao.createPerson(michael);
		final long wernerId = dao.createPerson(werner);
		final long timId = dao.createPerson(tim);
	
		final List<Person> persons2 = dao.findAllPersons();
		persons2.forEach(System.out::println);
	
		// $\mbox{\bfseries UPDATE }$
		dao.deletePersonById(michaelId);
		werner.setFirstName("Dr. h.c. Werner");
	
		// $\mbox{\bfseries DELETE }$
		dao.deletePersonById(timId);
		
		final List<Person> persons = dao.findAllPersons();
		persons.forEach(System.out::println);
	}
}
