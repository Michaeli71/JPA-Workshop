package a_part_3_4.solutions;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbetung des neuen Date and Time API mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class OrderExample extends DbBase
{
    public static void main(final String[] args)  
    {
    	new OrderExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-3-4-SOLUTIONS";
	}


	@Override
	protected void executeStatements(final EntityManager entityManager)
    {
        // Einfügeoperationen ausführen und das Resultat prüfen
        final Customer michael = new Customer("Michael", LocalDate.of(1971, 2, 7));        
        final Customer tim = new Customer("Tim", LocalDate.of(1971, 3, 27));
        
        entityManager.persist(michael);
        entityManager.persist(tim);

        
        // Orders
        Order bookOrder1 = new Order("JAVA-BOOKS", LocalDate.of(2021, 2, 14));
        OrderItem book1 = new OrderItem("Der Weg zum Java-Profi", 50, 2);
        OrderItem book2 = new OrderItem("Java Challenge", 35, 1);
        OrderItem book3 = new OrderItem("Java 9 bis 14", 30, 1);
        bookOrder1.addOrderItem(book1);
        bookOrder1.addOrderItem(book2);
        bookOrder1.addOrderItem(book3);
        
        Order bookOrder2 = new Order("PYTHON-BOOKS", LocalDate.of(2020, 12, 12));
        OrderItem bookPC = new OrderItem("Python Challenge", 35, 5);
        bookOrder2.addOrderItem(bookPC);
        
        Order gamesOrder = new Order("Anno Games", LocalDate.of(2021, 12, 20));
        OrderItem game1 = new OrderItem("Anno 1701", 35, 1);
        OrderItem game2 = new OrderItem("Anno 1800", 55, 2);
        gamesOrder.addOrderItem(game1);
        gamesOrder.addOrderItem(game2);
        
        entityManager.persist(bookOrder1);
        entityManager.persist(bookOrder2);
        entityManager.persist(gamesOrder);
        
        final String jpqlOrders = "SELECT order FROM Order order";
        final TypedQuery<Order> typedQuery2 = entityManager.createQuery(jpqlOrders, Order.class);
        typedQuery2.getResultList().forEach(System.out::println);
                
        // Customer + Order verbinden
        tim.getOrders().add(bookOrder1);
        tim.getOrders().add(bookOrder2);
        bookOrder1.setOrderedBy(tim);
        bookOrder2.setOrderedBy(tim);

        michael.getOrders().add(gamesOrder);
        gamesOrder.setOrderedBy(michael);
        
        final String jpql = "SELECT customer FROM Customer customer";
        final TypedQuery<Customer> typedQuery = entityManager.createQuery(jpql, Customer.class);
        typedQuery.getResultList().forEach(System.out::println);
    }
}
