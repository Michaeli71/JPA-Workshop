package a_part_3_4.solutions;

import java.util.List;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbetung des neuen Date and Time API mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class TreeItemExample extends DbBase
{
    public static void main(final String[] args)  
    {
    	new TreeItemExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-3-4-SOLUTIONS";
	}


	@Override
	protected void executeStatements(final EntityManager entityManager)
    {
		TreeItem root = new TreeItem("Root");
		TreeItem analysis = new TreeItem("Analysis", root);
		TreeItem implementation = new TreeItem("Implementation", root);
		TreeItem deployment = new TreeItem("Deployment", root);
		 
		root.addChild(analysis);
		root.addChild(implementation);
		root.addChild(deployment);
		 
		TreeItem coding = new TreeItem("Coding", implementation);
		TreeItem testing = new TreeItem("Testing", implementation);		 
		implementation.addChild(coding);
		implementation.addChild(testing);
		 
		TreeItem codingI = new TreeItem("Coding I", coding);
		TreeItem codingII = new TreeItem("Coding II", coding);
		coding.addChild(codingI);
		coding.addChild(codingII);
		
		TreeItem objectModelling = new TreeItem("Object Modelling", analysis);
		analysis.addChild(objectModelling);
		
		TreeItem systemtest = new TreeItem("System Test", deployment);
		TreeItem rollout = new TreeItem("Rollout", deployment);
		deployment.addChild(systemtest);
		deployment.addChild(rollout);
		 
		entityManager.persist(root);
		
		printTreeSimple(entityManager, root);
		printTree(entityManager, root);
		printTree(entityManager, analysis);
		printTree(entityManager, implementation);
    }
	
	static void printTree(final EntityManager entityManager, TreeItem parent)
	{
		System.out.println(parent.getName());
		printTree(entityManager, parent, "");
	}
	
	static void printTree(final EntityManager entityManager, TreeItem parent, String indent)
	{
		List<TreeItem> children = parent.getChildren();

	    for (int i = 0; i < children.size(); i++)
	    {
	    	TreeItem childItem = children.get(i);
	        boolean isLast = i == children.size() - 1;

	        System.out.print(indent);
	        
	        if (isLast)
	            System.out.print("\\-- ");
	        else
	            System.out.print("|-- ");

	        System.out.println(childItem.getName());
	        if (!childItem.getChildren().isEmpty())
	        {
	            String newIndent = isLast ? "    " : "|   ";
	            printTree(entityManager, childItem, indent + newIndent);
	        }
	    }
	}
	
	private static void printTreeSimple(final EntityManager entityManager, TreeItem parent)
	{	     
	    System.out.println(parent.getName());
	     
	    List<TreeItem> children = parent.getChildren();
	    for (TreeItem child : children) {
	        System.out.println("|-- " + child.getName());
	        printChildren(child, 1);
	    }      
	}
	 
	private static void printChildren(TreeItem parent, int subLevel) {
		List<TreeItem> children = parent.getChildren();
	     
	    for (TreeItem child : children) {
	        for (int i = 0; i <= subLevel; i++) System.out.print("--- ");
	                 
	        System.out.println(child.getName());
	         
	        printChildren(child, subLevel + 1);
	    }
	}

}
