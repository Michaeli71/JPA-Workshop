package a_part_3_4.solutions;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Beispielklasse zur Modellierung einer Person mit JPA-Annotations
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
@Entity
@Table(name = "SIMPLE_CUSTOMER")
public class SimpleCustomer 
{
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private LocalDate birthday;

	@Embedded
	private SimpleAddress address;
	
	@Enumerated(EnumType.STRING)
	private Rating rating;
	
	@ElementCollection
	private List<String> hobbies = new ArrayList<>();
	
	private SimpleCustomer() {
	}

	public SimpleCustomer(String name, LocalDate birthday) {
		this.name = name;
		this.birthday = birthday;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getBirthday() {
		return birthday;
	}

	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}

	public SimpleAddress getAddress() {
		return address;
	}

	public void setAddress(SimpleAddress address) {
		this.address = address;
	}

	public Rating getRating() {
		return rating;
	}

	public void setRating(Rating rating) {
		this.rating = rating;
	}

	public List<String> getHobbies() {
		return hobbies;
	}

	public void setHobbies(List<String> hobbies) {
		this.hobbies = hobbies;
	}

	@Override
	public String toString() {
		return "SimpleCustomer [id=" + id + ", name=" + name + ", birthday=" + birthday + ", address=" + address
				+ ", rating=" + rating + ", hobbies=" + hobbies + "]";
	}
}
