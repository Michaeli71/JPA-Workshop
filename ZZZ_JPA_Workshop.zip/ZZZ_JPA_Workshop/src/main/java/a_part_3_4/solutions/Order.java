package a_part_3_4.solutions;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "ORDERS")
public class Order 
{
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private LocalDate orderDate;
	
	// Diskussion: Assoziation, Aggregation, Kompositon
	// Das ist eine wirklich Komposition => also, Teile sollen gelöscht werden, wenn "Ganzes", also Order gelöscht wird
	// Keine OrderItems ohne Order => orphanRemoval, um verwaiste Einträge zu entfernen
	@OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
	List<OrderItem> orderItems = new ArrayList<>();
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORDERED_BY_CUSTOMER_ID")
	Customer orderedBy;
	
	public Order()
	{}
	
	
	public Order(String name, LocalDate orderDate) {
		this.name = name;
		this.orderDate = orderDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public List<OrderItem> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}

	public void addOrderItem(OrderItem item)
	{
		this.orderItems.add(item);
		item.setOrder(this);
	}
	
	public void removeOrderItem(OrderItem item)
	{
		this.orderItems.remove(item);
		item.setOrder(null);
	}

	
	public Customer getOrderedBy() {
		return orderedBy;
	}

	public void setOrderedBy(Customer orderedBy) {
		this.orderedBy = orderedBy;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		return Objects.equals(id, other.id);
	}

	// toString()-Problematik
	@Override
	public String toString() {
		return "Order [id=" + id + ", name=" + name + ", orderDate=" + orderDate + ", orderItems=" + orderItems
				+ ", orderedBy=" + orderedBy() + "]";
	}


	private String orderedBy() {
		if (orderedBy == null)
			return "-/-";
		
		return orderedBy.getName();
	}
	
	
}