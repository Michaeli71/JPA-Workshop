package a_part_3_4.solutions;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;


/**
 * Beispielklasse zur Modellierung einer Person mit JPA-Annotations
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
@Entity
public class Customer 
{
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private LocalDate birthday;

	@OneToMany
	private Set<Order> orders = new HashSet<>();


	public Customer() {
	}

	public Customer(String name, LocalDate birthday) {
		this.name = name;
		this.birthday = birthday;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getBirthday() {
		return birthday;
	}

	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}

	
	public Set<Order> getOrders() {
		return orders;
	}

	public void setOrders(Set<Order> orders) {
		this.orders = orders;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", birthday=" + birthday + ", orders=" + orders + "]";
	}
	
	
}
