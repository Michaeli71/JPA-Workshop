package a_part_3_4.solutions;

import java.util.Objects;
import java.util.UUID;

import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class UuidBase 
{
	@Id
	private final String id;

	public UuidBase() 
	{
		this.id = UUID.randomUUID().toString();
	}

	public String getId() {
		return id;
	}

	// ACHTUNG: Das ist Konktrakt-konform, aber in diesem Kontext falsch !!!
	/*
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		UuidBase other = (UuidBase) obj;
		return Objects.equals(id, other.id);
	}
	*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof UuidBase))
			return false;
		
		UuidBase other = (UuidBase) obj;
		return Objects.equals(id, other.id);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
}
