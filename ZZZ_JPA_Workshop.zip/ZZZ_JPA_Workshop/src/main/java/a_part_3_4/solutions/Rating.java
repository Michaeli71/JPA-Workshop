package a_part_3_4.solutions;

public enum Rating {
	GOLD, SILVER, BRONZE, UNCLASSIFIED
}
