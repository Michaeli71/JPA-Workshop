package a_part_3_4.solutions;

import javax.persistence.Embeddable;

@Embeddable
public class SimpleAddress 
{
	String street;
	String houseNumber;
    String zip;
	String city;
	String country;
	
	public SimpleAddress()
	{		
	}

	public SimpleAddress(String street, String houseNumber, String zip, String city, String country) {
		this.street = street;
		this.houseNumber = houseNumber;
		this.zip = zip;
		this.city = city;
		this.country = country;
	}

	@Override
	public String toString() {
		return "SimpleAddress [street=" + street + ", houseNumber=" + houseNumber + ", zip=" + zip + ", city=" + city
				+ ", country=" + country + "]";
	}
}