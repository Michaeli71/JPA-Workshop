package a_part_3_4.solutions;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
 
@Entity
@Table
public class TreeItem {
    @Id
    @GeneratedValue 
    private Long id;
     
    @Column(length = 64)
    private String name;
     
    @OneToOne
    @JoinColumn(name = "parent_id")
    private TreeItem parent;
     
    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL)
    private List<TreeItem> children = new ArrayList<>();
     
    public TreeItem(String name, TreeItem parent) {
        this.name = name;
        this.parent = parent;
    }
     
    public TreeItem(String name) {
        this.name = name;
    }  
 
    public TreeItem() {
    }
 
    public Long getId() {
        return id;
    }
 
    public void setId(Long id) {
        this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public TreeItem getParent() {
        return parent;
    }
 
    public void setParent(TreeItem parent) {
        this.parent = parent;
    }
 
    public List<TreeItem> getChildren() {
        return children;
    }
 
    public void setChildren(List<TreeItem> children) {
        this.children = children;
    }
     
    public void addChild(TreeItem childItem) {
        this.children.add(childItem);
    }
}