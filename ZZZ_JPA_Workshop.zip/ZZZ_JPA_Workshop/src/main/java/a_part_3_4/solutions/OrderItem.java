package a_part_3_4.solutions;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class OrderItem
{
	@Id
	@GeneratedValue
	private Long id;
	
	private String article;
	private int price;
	private int count;

	@ManyToOne(fetch = FetchType.LAZY)
	private Order order;
	
	public OrderItem()
	{}
	
	public OrderItem(String article, int price, int count) {
		this.article = article;
		this.price = price;
		this.count = count;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getArticle() {
		return article;
	}

	public void setArticle(String article) {
		this.article = article;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderItem other = (OrderItem) obj;
		return Objects.equals(id, other.id);
	}

	// toString()-Problematik
	@Override
	public String toString() {
		return "OrderItem [id=" + id + ", article=" + article + ", price=" + price + ", count=" + count + ", order="
				+ order.getName() + "]";
	}
	
	
}