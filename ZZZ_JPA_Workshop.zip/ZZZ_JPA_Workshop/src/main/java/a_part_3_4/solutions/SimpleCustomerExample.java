package a_part_3_4.solutions;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbetung des neuen Date and Time API mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class SimpleCustomerExample extends DbBase
{
    public static void main(final String[] args)  
    {
    	new SimpleCustomerExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-3-4-SOLUTIONS";
	}


	@Override
	protected void executeStatements(final EntityManager entityManager)
    {
        // Einfügeoperationen ausführen und das Resultat prüfen
        final SimpleCustomer michael = new SimpleCustomer("Michael", LocalDate.of(1971, 2, 7));
        final SimpleAddress address1 = new SimpleAddress("In der Ey", "50", "8047", "Zürich", "Switzerland");
        michael.setAddress(address1);
        michael.setHobbies(List.of("Programming", "Hiking", "Home Cinema"));
        michael.setRating(Rating.SILVER);
        
        final SimpleCustomer tim = new SimpleCustomer("Tim", LocalDate.of(1971, 3, 27));
        final SimpleAddress address2 = new SimpleAddress("Friesenstrasse", "7", "24117", "Kiel", "Germany");
        tim.setAddress(address2);
        tim.setHobbies(List.of("Programming", "Eating"));
        tim.setRating(Rating.UNCLASSIFIED);
        
        entityManager.persist(michael);
        entityManager.persist(tim);

        final String jpql = "SELECT customer FROM SimpleCustomer customer";
        final TypedQuery<SimpleCustomer> typedQuery = entityManager.createQuery(jpql, SimpleCustomer.class);
        typedQuery.getResultList().forEach(System.out::println);
    }
}
