package a_part_3_4.exercises;

import java.util.List;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbetung des neuen Date and Time API mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class TreeItemExample extends DbBase
{
    public static void main(final String[] args)  
    {
    	new TreeItemExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-3-4-EXERCISES";
	}


	@Override
	protected void executeStatements(final EntityManager entityManager)
    {
		TreeItem root = new TreeItem("Root");
		TreeItem analysis = new TreeItem("Analysis", root);
		TreeItem implementation = new TreeItem("Implementation", root);
		 
		root.addChild(analysis);
		root.addChild(implementation);
		 
		TreeItem coding = new TreeItem("Coding", implementation);
		TreeItem testing = new TreeItem("Testing", implementation);
		 
		implementation.addChild(coding);
		implementation.addChild(testing);
		 
		TreeItem objectModelling = new TreeItem("Object Modelling", analysis);
		analysis.addChild(objectModelling);
		 
		entityManager.persist(root);
		
		printTreeSimple(entityManager, root);
		printTreeSimple(entityManager, analysis);
		printTreeSimple(entityManager, implementation);
    }
	
	private static void printTreeSimple(final EntityManager entityManager, TreeItem parent)
	{	     
	    System.out.println(parent.getName());
	     
	    List<TreeItem> children = parent.getChildren();
	    for (TreeItem child : children) {
	        System.out.println("|-- " + child.getName());
	        printChildren(child, 1);
	    }      
	}
	 
	private static void printChildren(TreeItem parent, int subLevel) {
		List<TreeItem> children = parent.getChildren();
	     
	    for (TreeItem child : children) {
	        for (int i = 0; i <= subLevel; i++) System.out.print("--- ");
	                 
	        System.out.println(child.getName());
	         
	        printChildren(child, subLevel + 1);
	    }
	}
}
