package a_part_3_4.exercises;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
 
@Entity
@Table
public class TreeItem {
    @Id
    @GeneratedValue 
    private Long id;
     
    @Column(length = 64)
    private String name;
     
    // TODO
    @Transient
    TreeItem parent = null;
    
    // TODO
    
    public TreeItem(String name, TreeItem parent) {
        this.name = name;
        this.parent = parent;
    }
     
    public TreeItem(String name) {
        this.name = name;
    }  
 
    public TreeItem() {
    }
 
    public Long getId() {
        return id;
    }
 
    public void setId(Long id) {
        this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public TreeItem getParent() {
        return parent;
    }
 
    public void setParent(TreeItem parent) {
        this.parent = parent;
    }    
    
    public void addChild(TreeItem childItem) {
    	// TODO
    }

	public List<TreeItem> getChildren() {
		// TODO 
		return List.of();
	}
}
