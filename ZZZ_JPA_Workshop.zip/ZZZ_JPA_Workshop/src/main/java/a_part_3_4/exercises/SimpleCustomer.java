package a_part_3_4.exercises;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SIMPLE_CUSTOMER")
public class SimpleCustomer 
{
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private LocalDate birthday;

	// TODO
	
	public SimpleCustomer(String name, LocalDate birthday) 
	{
		this.name = name;
		this.birthday = birthday;
	}

}
