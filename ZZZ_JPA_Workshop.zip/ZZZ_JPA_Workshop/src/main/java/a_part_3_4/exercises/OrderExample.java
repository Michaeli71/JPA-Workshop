package a_part_3_4.exercises;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbetung des neuen Date and Time API mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class OrderExample extends DbBase
{
    public static void main(final String[] args)  
    {
    	new OrderExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-3-4-EXERCISES";
	}


	@Override
	protected void executeStatements(final EntityManager entityManager)
    {
        // Einfügeoperationen ausführen und das Resultat prüfen
        final Customer michael = new Customer("Michael", LocalDate.of(1971, 2, 7));        
        final Customer tim = new Customer("Tim", LocalDate.of(1971, 3, 27));
        
        entityManager.persist(michael);
        entityManager.persist(tim);

        final String jpql = "SELECT customer FROM Customer customer";
        final TypedQuery<Customer> typedQuery = entityManager.createQuery(jpql, Customer.class);
        typedQuery.getResultList().forEach(System.out::println);
        
        // Orders
        
        
    }
}
