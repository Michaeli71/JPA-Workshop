package a_part_3_4.exercises;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity(name = "ORDERS")
public class Order 
{
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private LocalDate orderDate;

	// TODO
	
	public Order()
	{}
	
	
	public Order(String name, LocalDate orderDate) {
		this.name = name;
		this.orderDate = orderDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
}