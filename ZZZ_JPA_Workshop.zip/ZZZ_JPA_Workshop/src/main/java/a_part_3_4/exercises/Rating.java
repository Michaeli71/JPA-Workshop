package a_part_3_4.exercises;

public enum Rating {
	GOLD, SILVER, BRONZE, UNCLASSIFIED
}
