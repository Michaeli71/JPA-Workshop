package utils;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.RollbackException;

// Template Method Pattern
public abstract class DbBase 
{
	private EntityManagerFactory entityManagerFactory;
		
	protected abstract String getPuName();
	protected abstract void executeStatements(final EntityManager entityManager);
	
	// HOOK
	protected void handleRollbackException(RollbackException rbe)
	{	
	}

	protected void secondAction(EntityManager entityManager)
	{		
	}
	
	protected EntityManagerFactory getEntityManagerFactory() {
		return entityManagerFactory;
	}
	
	public final void dbAcessAlgorithm() 
	{
		entityManagerFactory = Persistence.createEntityManagerFactory(getPuName());
        final EntityManager entityManager = entityManagerFactory.createEntityManager();

        try
        {
            performJPAActions(entityManager);
        }
        finally
        {
            entityManager.close();
            entityManagerFactory.close();
        }
	}
	
	private void performJPAActions(final EntityManager entityManager)
    {
        try
        {
            entityManager.getTransaction().begin();

            executeStatements(entityManager);

            entityManager.getTransaction().commit();
            
            entityManager.getTransaction().begin();

            secondAction(entityManager);

            entityManager.getTransaction().commit();
        }
        catch (RollbackException e) {
			handleRollbackException(e);
			entityManager.getTransaction().rollback();
		}
        catch (final Exception e)
        {
        	e.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
	

}
