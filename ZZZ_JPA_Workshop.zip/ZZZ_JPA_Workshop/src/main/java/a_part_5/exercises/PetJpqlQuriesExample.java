package a_part_5.exercises;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import a_part_5.Pet;
import utils.DbBase;

/**
 * Beispiel zur Demonstration von Objekterzeugungs-Queries mit JPQL
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class PetJpqlQuriesExample extends DbBase {
	public static void main(final String[] args) {
		new PetJpqlQuriesExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-5-SOLUTIONS";
	}

	@Override
	protected  void executeStatements(final EntityManager entityManager) {
	
		createPets(entityManager);
		
		LocalDate silvester2015 = LocalDate.of(2015, 12, 31);
		TypedQuery<Pet> petsQuery = null; // TODO
		List<Pet> pets = petsQuery.getResultList();
		
		for (Pet pet : pets) {
			System.out.println(pet);
		}
		
		// -------------------------------------------
		
		TypedQuery<Pet> petsUnknwonMotherQuery = null; // TODO
		List<Pet> petsUnknownMother = petsUnknwonMotherQuery.getResultList();
				
		for (Pet pet : petsUnknownMother) {
			System.out.println(pet);
		}
		
		// -------------------------------------------
		
		TypedQuery<Pet> petsMotherQuery = null; // TODO
		List<Pet> petsWithMother = petsMotherQuery.getResultList();
				
		for (Pet pet : petsWithMother) {
			System.out.println(pet);
		}
		
	}

	private void createPets(final EntityManager entityManager) {
		Pet pet1 = new Pet("Pete", LocalDate.of(2020, 7, 9));
		Pet pet2 = new Pet("Michaela", LocalDate.of(1999, 2, 7));
		Pet pet3 = new Pet("Hasso", LocalDate.of(2004, 9, 7));
		Pet pet4 = new Pet("King", LocalDate.of(2017, 12, 17));
		Pet pet5 = new Pet("Sarah", LocalDate.of(2007, 11, 23));
		
		pet3.setMother(pet2);
		pet5.setMother(pet2);
		
		entityManager.persist(pet1);
		entityManager.persist(pet2);
		entityManager.persist(pet3);
		entityManager.persist(pet4);
		entityManager.persist(pet5);
	}
}
