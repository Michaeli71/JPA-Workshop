package a_part_5;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Movie {

    @Id
    @GeneratedValue
    Long id;

    String title;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="rental_id")
    Rental belongsToRental;
    
    public Movie()
    {    	
    }
    
	public Movie(String title) {
		this.title = title;
	}

    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Rental getBelongsToRental() {
		return belongsToRental;
	}

	public void setBelongsToRental(Rental belongsToRental) {
		this.belongsToRental = belongsToRental;
	}


	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}

	@Override
	public String toString() {
		return "Movie [id=" + id + ", title=" + title + "]";
	}
}