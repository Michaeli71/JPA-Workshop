package a_part_5;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Pet {

	@Id
	@GeneratedValue
	Long id;

	String name;
	LocalDate birthday;

	@OneToOne(optional = true)
	Pet mother;

	public Pet() {
	}

	public Pet(String name, LocalDate birthday) {
		this.name = name;
		this.birthday = birthday;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public LocalDate getBirthday() {
		return birthday;
	}

	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}

	public Pet getMother() {
		return mother;
	}

	public void setMother(Pet mother) {
		this.mother = mother;
	}

	@Override
	public String toString() {
		return "Pet [id=" + id + ", name=" + name + ", birthday=" + birthday + ", mother=" + mother + "]";
	}
	
	
}