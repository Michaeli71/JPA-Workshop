package a_part_5.solutions;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import a_part_5.Movie;
import a_part_5.Rental;
import a_part_5.User;
import utils.DbBase;

/**
 * Beispiel zur Demonstration von Objekterzeugungs-Queries mit JPQL
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class MovieRentalJoinFetchExample extends DbBase {
	public static void main(final String[] args) {
		new MovieRentalJoinFetchExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-5-SOLUTIONS";
	}

	@Override
	protected  void executeStatements(final EntityManager entityManager) {
		User user1 = new User("Peter");
		User user2 = new User("Michael");
		User user3 = new User("James");
		
		Rental rental1 = new Rental();
		Rental rental2 = new Rental();
		
		Movie movie1 = new Movie("Algebra");
		Movie movie2 = new Movie("Algorithms");
		Movie movie3 = new Movie("Java");
		Movie movie4 = new Movie("Asterix");

		entityManager.persist(user1);
		entityManager.persist(user2);
		entityManager.persist(user3);

		entityManager.persist(movie1);
		entityManager.persist(movie2);
		entityManager.persist(movie3);
		entityManager.persist(movie4);
		
		rental1.getRenters().add(user1);
		user1.getRentals().add(rental1);
		
		rental1.getMovies().add(movie1);
		movie1.setBelongsToRental(rental1);
		rental1.getMovies().add(movie2);
		movie2.setBelongsToRental(rental1);

		rental2.getRenters().add(user2);
		user2.getRentals().add(rental2);
		rental2.getMovies().add(movie3);
		movie3.setBelongsToRental(rental2);
		rental2.getMovies().add(movie4);
		movie4.setBelongsToRental(rental2);
		
		entityManager.persist(rental1);
		entityManager.persist(rental2);
		
		entityManager.flush();
		entityManager.clear();

		System.out.println("-- executing query N + 1 --");
		
		// N + 1
		User michael = entityManager.find(User.class, 2L);
		for (Rental rental : michael.getRentals())
		{
			System.out.println(michael.getName() + " - " + rental);
		}
				
		entityManager.clear();
		System.out.println("-- executing query N + 1 ^ 2--");
		
		// N + 1 "im Quadrat"
		User userPeter = entityManager.find(User.class, 1L);
		for (Rental rental : userPeter.getRentals())
		{
			for (Movie movie : rental.getMovies())
				System.out.println(movie);
		}
		
		// -------------------------------------------------
		entityManager.clear();
		
		System.out.println("-- executing query --");
		Query query = entityManager.createQuery("SELECT DISTINCT u FROM User u JOIN FETCH u.rentals WHERE u.id = 2");
		List<User> userAndRentals = query.getResultList();
		
		for (User user : userAndRentals) {
			System.out.println(user.getName() + " - " + user.getRentals());
		}
		
		entityManager.clear();
		
		System.out.println("-- executing query 2 --");
		Query query2 = entityManager.createQuery("SELECT DISTINCT u FROM User u JOIN FETCH u.rentals r " +
				" JOIN FETCH r.movies m" +
				" WHERE u.id = 1");
		List<User> userAndRentalsAndMovies = query2.getResultList();
		
		for (User user : userAndRentalsAndMovies) {
			for (Rental rental : user.getRentals())
			{
				for (Movie movie : rental.getMovies())
					System.out.println(movie);
			}
		}
	}
}
