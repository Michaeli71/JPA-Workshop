package a_part_5.solutions;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import a_part_5.Pet;
import utils.DbBase;

/**
 * Beispiel zur Demonstration von Objekterzeugungs-Queries mit JPQL
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class PetJpqlQuriesExample extends DbBase {
	public static void main(final String[] args) {
		new PetJpqlQuriesExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-PART-5-SOLUTIONS";
	}

	@Override
	protected  void executeStatements(final EntityManager entityManager) {
	
		createPets(entityManager);
		
		LocalDate silvester2015 = LocalDate.of(2015, 12, 31);
		TypedQuery<Pet> petsQueryBornBefore = entityManager.createQuery(
			    "select pet from Pet as pet where pet.birthday < ?1", Pet.class)
			    .setParameter(1, silvester2015);
		List<Pet> pets = petsQueryBornBefore.getResultList();
		
		System.out.println("petsQueryBornBefore");
		for (Pet pet : pets) {
			System.out.println(pet);
		}
		
		
		TypedQuery<Pet> petsQueryBornAfter = entityManager.createQuery(
			    "select pet from Pet as pet where pet.birthday > ?1", Pet.class)
			    .setParameter(1, silvester2015);
		List<Pet> pets2 = petsQueryBornAfter.getResultList();
		
		System.out.println("petsQueryBornAfter");
		for (Pet pet : pets2) {
			System.out.println(pet);
		}
		// -------------------------------------------
		
		TypedQuery<Pet> petsUnknwonMotherQuery = entityManager.createQuery(
			    "select pet from Pet as pet where pet.mother IS null", Pet.class);
		List<Pet> petsUnknownMother = petsUnknwonMotherQuery.getResultList();
				
		System.out.println("petsUnknownMother");
		for (Pet pet : petsUnknownMother) {
			System.out.println(pet);
		}
		
		// -------------------------------------------
		
		TypedQuery<Pet> petsMotherQuery = entityManager.createQuery(
			    "select pet from Pet as pet join pet.mother as mom where mom.name = ?1", Pet.class)
			    .setParameter(1, "Michaela");
		List<Pet> petsWithMother = petsMotherQuery.getResultList();
				
		System.out.println("petsWithMother");
		for (Pet pet : petsWithMother) {
			System.out.println(pet);
		}		
	}

	private void createPets(final EntityManager entityManager) {
		Pet pet1 = new Pet("Pete", LocalDate.of(2020, 7, 9));
		Pet pet2 = new Pet("Michaela", LocalDate.of(1999, 2, 7));
		Pet pet3 = new Pet("Hasso", LocalDate.of(2004, 9, 7));
		Pet pet4 = new Pet("King", LocalDate.of(2017, 12, 17));
		Pet pet5 = new Pet("Sarah", LocalDate.of(2007, 11, 23));
		
		pet3.setMother(pet2);
		pet5.setMother(pet2);
		
		entityManager.persist(pet1);
		entityManager.persist(pet2);
		entityManager.persist(pet3);
		entityManager.persist(pet4);
		entityManager.persist(pet5);
	}
}
