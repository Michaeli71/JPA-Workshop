package a_part_2;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Movie 
{
	@Id
	private Long id;
	private String title;

	private boolean rented;
	private LocalDate releaseDate;

	protected Movie() {
	}

	public Movie(Long id, String title, boolean rented, LocalDate releaseDate) {
		this.id = id;
		this.title = title;
		this.rented = rented;
		this.releaseDate = releaseDate;
	}

	public boolean isRented() {
		return rented;
	}

	public void setRented(boolean rented) {
		this.rented = rented;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}

	public LocalDate getReleaseDate() {
		return releaseDate;
	}


	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}


	@Override
	public String toString() {
		return "Movie [id=" + id + ", title=" + title + ", rented=" + rented + ", releaseDate=" + releaseDate + "]";
	}	
}