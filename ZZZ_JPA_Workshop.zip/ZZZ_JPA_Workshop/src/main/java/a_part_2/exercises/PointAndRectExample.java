package a_part_2.exercises;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import a_part_2.Point;
import a_part_2.Rect;

/**
 * Beispiel zur Demonstration der Verarbetung des neuen Date and Time API mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class PointAndRectExample
{
    public static void main(final String[] args) throws Exception
    {
        final EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("java-profi-PU-PART-2-EXERCISES");
        final EntityManager entityManager = entityManagerFactory.createEntityManager();

        try
        {
            performJPAActions(entityManager);
        }
        finally
        {
            entityManager.close();
            entityManagerFactory.close();
        }
    }

    private static void performJPAActions(final EntityManager entityManager)
    {
        try
        {
            entityManager.getTransaction().begin();

            executeStatements(entityManager);

            entityManager.getTransaction().commit();
        }
        catch (final Exception e)
        {
        	e.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

	private static void executeStatements(final EntityManager entityManager)	
	{
		Point p = new Point(7, 7);
		Rect r = new Rect(7, 7, 10 * 7, 10 * 7);
		
		// TODO
		
	    final String jpql = null;

	    // TODO
	}
}
