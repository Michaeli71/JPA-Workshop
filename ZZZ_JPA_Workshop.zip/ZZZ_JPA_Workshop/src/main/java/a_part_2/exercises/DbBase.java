package a_part_2.exercises;


public abstract class DbBase 
{
	// TODO
}