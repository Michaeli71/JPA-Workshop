package a_part_2.exercises;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import a_part_2.Movie;


/**
 * Beispiel zur Demonstration der Verarbetung des neuen Date and Time API mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class BasicStepsExample
{
    public static void main(final String[] args) throws Exception
    {
        final EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("java-profi-PU-PART-2-EXERCISES");
        final EntityManager entityManager = entityManagerFactory.createEntityManager();

        try
        {
            performJPAActions(entityManager);
        }
        finally
        {
            entityManager.close();
            entityManagerFactory.close();
        }
    }

    private static void performJPAActions(final EntityManager entityManager)
    {
        try
        {
            entityManager.getTransaction().begin();

            executeStatements(entityManager);

            entityManager.getTransaction().commit();
        }
        catch (final Exception e)
        {
        	e.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

	private static void executeStatements(final EntityManager entityManager)
	{
	    final Movie movie1 = new Movie(1L, "XYZ Gelöste Rätsel", false, LocalDate.of(1977, 5, 18));
	    final Movie movie2 = new Movie(2L, "Bames Jond", true, LocalDate.of(2017, 9, 9));
	
	    entityManager.persist(movie1);
	    entityManager.persist(movie2);
	
	    final String jpql = "SELECT m FROM Movie m";
	    final TypedQuery<Movie> typedQuery = entityManager.createQuery(jpql, Movie.class);
	    typedQuery.getResultList().forEach(System.out::println);
	}
}
