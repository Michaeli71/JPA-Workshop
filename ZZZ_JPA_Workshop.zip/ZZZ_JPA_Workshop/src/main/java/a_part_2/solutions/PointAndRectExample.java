package a_part_2.solutions;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import a_part_2.Point;
import a_part_2.Rect;


/**
 * Beispiel zur Demonstration der Verarbetung des neuen Date and Time API mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class PointAndRectExample
{
    public static void main(final String[] args)  
    {
        final EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("java-profi-PU-PART-2-SOLUTIONS");
        final EntityManager entityManager = entityManagerFactory.createEntityManager();

        try
        {
            performJPAActions(entityManager);
        }
        finally
        {
            entityManager.close();
            entityManagerFactory.close();
        }
    }

    private static void performJPAActions(final EntityManager entityManager)
    {
        try
        {
            entityManager.getTransaction().begin();

            executeStatements(entityManager);

            entityManager.getTransaction().commit();
        }
        catch (final Exception e)
        {
        	e.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }

	private static void executeStatements(final EntityManager entityManager)
	{
		for (int i = 0; i < 20; i++) {
			Point p = new Point(i, i);
			entityManager.persist(p);
		}

		for (int i = 0; i < 10; i++) {
			Rect r = new Rect(i, i, 10 * i, 10 * i);
			entityManager.persist(r);
		}
		
	    final String jpql = "SELECT p FROM Point p";
	    final TypedQuery<Point> typedQuery = entityManager.createQuery(jpql, Point.class);
	    typedQuery.getResultList().forEach(System.out::println);
	    
	    final String jpql2 = "SELECT r FROM Rect r";
	    final TypedQuery<Rect> typedQuery2 = entityManager.createQuery(jpql2, Rect.class);
	    typedQuery2.getResultList().forEach(System.out::println);
	}
}
