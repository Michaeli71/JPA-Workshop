package a_part_2.solutions;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public abstract class DbBase 
{
	protected abstract String getPuName();
	protected abstract void executeStatements(final EntityManager entityManager);
	
	
	protected void dbAcessAlgorithm() 
	{
		final EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory(getPuName());
        final EntityManager entityManager = entityManagerFactory.createEntityManager();

        try
        {
            performJPAActions(entityManager);
        }
        finally
        {
            entityManager.close();
            entityManagerFactory.close();
        }
	}
	
	private void performJPAActions(final EntityManager entityManager)
    {
        try
        {
            entityManager.getTransaction().begin();

            executeStatements(entityManager);

            entityManager.getTransaction().commit();
        }
        catch (final Exception e)
        {
        	e.printStackTrace();
            entityManager.getTransaction().rollback();
        }
    }
}
