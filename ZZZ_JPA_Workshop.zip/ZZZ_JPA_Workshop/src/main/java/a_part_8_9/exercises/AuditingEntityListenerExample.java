package a_part_8_9.exercises;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration einfacher Zugriffe auf die Datenbank mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class AuditingEntityListenerExample extends DbBase
{
	public static void main(final String[] args) 
	{
		new AuditingEntityListenerExample().dbAcessAlgorithm();
	}

    @Override
    protected String getPuName() {
        return "java-profi-PU-PART-8-9-EXERCISES";
    }

    @Override
    protected void executeStatements(EntityManager entityManager) {

    	AuditableEmployee emp = new AuditableEmployee();
		emp.setName("Tom");

		entityManager.persist(emp);

		entityManager.flush();
		entityManager.clear();

		// Causes PostLoad to be fired
		emp = entityManager.find(AuditableEmployee.class, 1);
		System.out.println(emp);

		emp.setName("Michael");
		System.out.println(emp);
		entityManager.persist(emp);

		// ohne das wird UPDATE nicht ausgeführt
		entityManager.flush();

		entityManager.detach(emp);
		emp = entityManager.find(AuditableEmployee.class, 1);
		System.out.println(emp);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// => PRE / POST-DELETE
		System.out.println("REMOVING");
		entityManager.remove(emp);				
	}
}
