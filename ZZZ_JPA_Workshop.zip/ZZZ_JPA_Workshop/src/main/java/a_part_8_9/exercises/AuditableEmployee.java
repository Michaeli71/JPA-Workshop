package a_part_8_9.exercises;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PostPersist;
import javax.persistence.PrePersist;
import javax.persistence.Transient;


@Entity
public class AuditableEmployee {
	@Id
	@GeneratedValue
	private int id;
	private String name;

	@Transient
	private String greeting;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	
	@Override
	public String toString() {
		return "AuditableEmployee [id=" + id + ", name=" + name + ", greeting=" + greeting + "]";
	}

	@PrePersist
	public void logNewEmployyeeAttempt() {
		System.err.println("Attempting to add new employee " + this);
	}
	    
	@PostPersist
	public void logNewEmployeeAdded() {
	    System.err.println("Added employee '" + this);
	}

	// TODO
}
