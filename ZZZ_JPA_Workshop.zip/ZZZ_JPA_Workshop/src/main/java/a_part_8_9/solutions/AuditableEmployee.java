package a_part_8_9.solutions;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import javax.persistence.Transient;

import part8_callback_listeners.intro.AuditListener;

@EntityListeners(AuditListener.class)
@Entity
public class AuditableEmployee {
	@Id@GeneratedValue
	private int id;
	private String name;

	@Transient
	private String greeting;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	
	@Override
	public String toString() {
		return "AuditableEmployee [id=" + id + ", name=" + name + ", greeting=" + greeting + "]";
	}

	@PrePersist
	public void logNewEmployyeeAttempt() {
		System.err.println("Attempting to add new employee " + this);
	}
	    
	@PostPersist
	public void logNewEmployeeAdded() {
	    System.err.println("Added employee '" + this);
	}
	    
	@PreRemove
	public void logUserRemovalAttempt() {
		System.err.println("Attempting to delete employee: " + getName());
	}
	    
	@PostRemove
	public void logUserRemoval() {
		System.err.println("Deleted employee: " + getName());
	}

	@PreUpdate
	public void logUserUpdateAttempt() {
		System.err.println("Attempting to update employee: " + getName());
	}

	@PostUpdate
	public void logUserUpdate() {
	    System.err.println("Updated employee: " + getName());
	}

	@PostLoad
	public void initializeTransientData() {
		System.err.println("initialized transient data for employee: " + getName());
	    greeting = "Hello " + " " + getName();
	}
}
