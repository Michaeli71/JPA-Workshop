package a_part_8_9.solutions;

import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

public class AuditTrailListener {
    
    @PrePersist
    @PreUpdate
    @PreRemove
    private void beforeAnyUpdate(AuditableEmployee emp) {
        if (emp.getId() == 0) {
        	System.out.println("[Emplyoee AUDIT] About to add a Emplyoee");
        } else {
        	System.out.println("[Emplyoee AUDIT] About to update/delete Emplyoee: " + emp.getId());
        }
    }
    
    @PostPersist
    @PostUpdate
    @PostRemove
    private void afterAnyUpdate(AuditableEmployee emp) {
    	System.out.println("[Emplyoee AUDIT] add/update/delete complete for Emplyoee: " + emp.getId());
    }
    
    @PostLoad
    private void afterLoad(AuditableEmployee emp) {
    	System.out.println("[Emplyoee AUDIT] Emplyoee loaded from database: " + emp.getId());
    }
}