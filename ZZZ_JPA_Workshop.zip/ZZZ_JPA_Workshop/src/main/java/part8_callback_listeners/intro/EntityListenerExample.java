package part8_callback_listeners.intro;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration einfacher Zugriffe auf die Datenbank mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class EntityListenerExample extends DbBase
{
	public static void main(final String[] args) 
	{
		new EntityListenerExample().dbAcessAlgorithm();
	}

    @Override
    protected String getPuName() {
        return "java-profi-PU-LISTENERS";
    }

    @Override
    protected void executeStatements(EntityManager entityManager) {

		Employee emp = new Employee();
		emp.setName("Tom");

		Address addr = new Address();
		addr.setId(1);
		addr.setStreet("street");
		addr.setCity("city");
		addr.setState("state");
		emp.setAddress(addr);

		entityManager.persist(emp);

		entityManager.flush();
		entityManager.clear();

		System.out.println("ADDRESS age: " + addr.getTimeSinceLastSyncInMs());
		System.out.println("ADDRESS last: " + addr.getLastUpdated());

		// Causes PostLoad to be fired
		emp = entityManager.find(Employee.class, 1);
		System.out.println(emp);

		addr = emp.getAddress();
		emp.setAddress(null);
		//entityManager.remove(addr);

		System.out.println("ADDRESS age: " + addr.getTimeSinceLastSyncInMs());
		System.out.println("ADDRESS last: " + addr.getLastUpdated());

		emp.setName("Michael");
		System.out.println(emp);
		entityManager.persist(emp);

		// ohne das wird UPDATE nicht ausgeführt
		entityManager.flush();

		entityManager.detach(emp);
		emp = entityManager.find(Employee.class, 1);
		System.out.println(emp);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// => PRE / POST-DELETE
		System.out.println("REMOVING");
		entityManager.remove(emp);
				
		addr = entityManager.find(Address.class, 1);
		System.out.println("ADDRESS age: " + addr.getTimeSinceLastSyncInMs());
	}
}
