package part8_callback_listeners.intro;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;
import javax.persistence.Transient;

@Entity
public class Employee {
	@Id@GeneratedValue
	private int id;
	private String name;

	@ManyToOne(cascade = CascadeType.PERSIST)
	Address address;

	@Transient
	private String greeting;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee id: " + getId() + " name: " + getName() + " with " + getAddress();
	}
	
	@PrePersist
	public void logNewEmployyeeAttempt() {
		System.err.println("Attempting to add new employee " + this);
	}
	    
	@PostPersist
	public void logNewEmployeeAdded() {
	    System.err.println("Added employee '" + this);
	}
	    
	@PreRemove
	public void logUserRemovalAttempt() {
		System.err.println("Attempting to delete employee: " + getName());
	}
	    
	@PostRemove
	public void logUserRemoval() {
		System.err.println("Deleted employee: " + getName());
	}

	@PreUpdate
	public void logUserUpdateAttempt() {
		System.err.println("Attempting to update employee: " + getName());
	}

	@PostUpdate
	public void logUserUpdate() {
	    System.err.println("Updated employee: " + getName());
	}

	@PostLoad
	public void initializeTransientData() {
		System.err.println("initialized transient data for employee: " + getName());
	    greeting = "Hello " + " " + getName();
	}
}
