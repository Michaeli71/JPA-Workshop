package part8_callback_listeners.intro;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;
import javax.persistence.Transient;

@EntityListeners(LastUpdateListener.class)
@Entity
public class Address implements LastUpdateAware
{
	@Id
	private int id;
	private String street;
	private String city;
	private String state;
	private String zip;
	
	private LocalDateTime lastUpdated;

	@Transient
	private long syncTimeInMs; 
		
    @PostPersist
    @PostUpdate
    @PostLoad
    public void resetSyncTime()
	{	
		System.out.println(">>>>>>>resetSyncTime()");
		syncTimeInMs = System.currentTimeMillis();
	}	
	
    public long getTimeSinceLastSyncInMs()
	{	
		return System.currentTimeMillis() - syncTimeInMs;
	}
	
    
	// Befüllung durch Listener
	@Override
	public void setLastUpdated(LocalDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
	public LocalDateTime getLastUpdated() {
		return lastUpdated;
	}


	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String address) {
		this.street = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "Address id: " + getId() + ", street: " + getStreet() + ", city: " + getCity() + ", state: " + getState()
				+ ", zip: " + getZip();
	}
}
