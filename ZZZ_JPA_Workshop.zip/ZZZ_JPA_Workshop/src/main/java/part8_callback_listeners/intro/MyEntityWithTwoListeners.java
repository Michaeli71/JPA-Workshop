package part8_callback_listeners.intro;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;

@Entity
@EntityListeners({ FirstListener.class, SecondListener.class })
public class MyEntityWithTwoListeners 
{
	// ...
}