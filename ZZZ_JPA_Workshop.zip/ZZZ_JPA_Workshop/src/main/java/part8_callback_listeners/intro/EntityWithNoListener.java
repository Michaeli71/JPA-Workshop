package part8_callback_listeners.intro;

import javax.persistence.Entity;
import javax.persistence.ExcludeSuperclassListeners;

@Entity
@ExcludeSuperclassListeners
public class EntityWithNoListener extends MyEntityWithTwoListeners 
{
	// ...
}