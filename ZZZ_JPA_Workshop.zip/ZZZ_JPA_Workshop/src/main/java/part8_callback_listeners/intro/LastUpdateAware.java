package part8_callback_listeners.intro;

import java.time.LocalDateTime;

public interface LastUpdateAware 
{
	public void setLastUpdated(LocalDateTime lastUpdated); 
}
