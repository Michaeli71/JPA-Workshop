package part8_callback_listeners.intro;

import java.time.LocalDateTime;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

public class LastUpdateListener 
{
    /**
     * automatic property set before any database persistence
     */
    @PreUpdate
    @PrePersist
    public void setLastUpdate(LastUpdateAware destinationObj) 
    {
    	destinationObj.setLastUpdated(LocalDateTime.now());
    }
}