package part8_callback_listeners.intro;

import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

public class AuditListener {
    
    @PrePersist
    @PreUpdate
    @PreRemove
    private void beforeAnyUpdate(Employee user) {
        if (user.getId() == 0) {
        	System.out.println("[Emplyoee AUDIT] About to add a Emplyoee");
        } else {
        	System.out.println("[Emplyoee AUDIT] About to update/delete Emplyoee: " + user.getId());
        }
    }
    
    @PostPersist
    @PostUpdate
    @PostRemove
    private void afterAnyUpdate(Employee user) {
    	System.out.println("[Emplyoee AUDIT] add/update/delete complete for Emplyoee: " + user.getId());
    }
    
    @PostLoad
    private void afterLoad(Employee user) {
    	System.out.println("[Emplyoee AUDIT] Emplyoee loaded from database: " + user.getId());
    }
}