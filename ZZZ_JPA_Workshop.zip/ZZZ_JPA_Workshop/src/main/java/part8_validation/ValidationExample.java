package part8_validation;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.RollbackException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import utils.DbBase;

/**
 * Beispiel zur Demonstration einfacher Zugriffe auf die Datenbank mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class ValidationExample extends DbBase
{
	public static void main(final String[] args) 
	{
		new ValidationExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-VALIDATION";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) 
	{		
		UserWithValidation user = new UserWithValidation();
		user.setWorking(false);
		user.setAboutMe("No info about me!");
		user.setAge(11);
	
		entityManager.persist(user);
		System.out.println(user);
	}
	
	@Override
	protected void handleRollbackException(RollbackException e) {
		Set<ConstraintViolation<?>> violations = ((ConstraintViolationException) e.getCause())
				.getConstraintViolations();
		for (ConstraintViolation v : violations) {
			System.err.println(v);
		}
	}
}
