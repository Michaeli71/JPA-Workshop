package part8_validation.custom;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CheckEnumValidator implements ConstraintValidator<CheckEnum, String> 
{	
	Class<?> type;

	@Override
	public void initialize(CheckEnum constraintAnnotation) 
	{
		type = constraintAnnotation.type();
		if (!type.isEnum())
			throw new IllegalArgumentException("type is not an enum");
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) 
	{			
		if (value == null)
			return true;
		
		Enum<?>[] enumValues = (Enum<?>[])type.getEnumConstants();		
		for (Enum<?> enumValue : enumValues)
		{
			if (enumValue.name().equals(value.trim()))
				return true;					
		}		
		return false;
	}
}
