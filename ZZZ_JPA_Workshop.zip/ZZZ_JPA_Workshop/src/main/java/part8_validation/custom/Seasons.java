package part8_validation.custom;

public enum Seasons {
	SPRING, SUMMER, AUTUMN, WINTER
}
