package part8_validation.custom;

public enum SpecialColors {
	RED, GREEN, BLUE
}
