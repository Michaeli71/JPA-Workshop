package part8_validation.custom;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

public class CustomValidatorsExample {

	public static void main(String[] args) 
	{
		ValidatedDomainClass dateCheck = new ValidatedDomainClass();
		dateCheck.depositDate = "1971-02-07";
		dateCheck.publicationDate = "07.02.1971";   
		dateCheck.collectionDate = "07.02.71";  
		
		// ENum-Validator
		dateCheck.season = "SUMMER";
		dateCheck.color = "GREEN";
		dateCheck.value = "Will";
		
		try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory())
		{
			Validator validator = factory.getValidator();
			
			Set<ConstraintViolation<ValidatedDomainClass>> constraintViolations = validator.validate(dateCheck);

			if (!constraintViolations.isEmpty()) {
				constraintViolations.forEach(constraintViolation -> System.out.println(constraintViolation.getPropertyPath() + " / " +
						constraintViolation.getInvalidValue() + " / " +
						constraintViolation.getMessage() ));
			}
		}
	}	
}
