package part8_validation.custom;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CheckListOfValuesValidator implements ConstraintValidator<CheckListOfValues, String> {
	
	String[] allowedValues;

	@Override
	public void initialize(CheckListOfValues constraintAnnotation) {
		allowedValues = constraintAnnotation.allowedValues();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
				
		if (value == null)
			return false;
		
		for (String allowedValue : allowedValues)
		{
			if (allowedValue.equals(value.trim()))
				return true;					
		}
		
		return false;
	}
}
