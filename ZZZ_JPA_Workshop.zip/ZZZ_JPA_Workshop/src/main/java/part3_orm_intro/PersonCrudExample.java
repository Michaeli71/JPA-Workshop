package part3_orm_intro;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 * Beispiel zur Demonstration einfacher Zugriffe auf die Datenbank mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class PersonCrudExample {
	public static void main(final String[] args) throws Exception {
		// Zum Applikationsstart: Einlesen der Konfiguration "persistence.xml"
		final EntityManagerFactory entityManagerFactory = Persistence
				.createEntityManagerFactory("java-profi-PU-ORM-INTRO");

		// Zur Verarbeitung von Daten => EntityManager bietet Zugriff auf Datenbank
		final EntityManager entityManager = entityManagerFactory.createEntityManager();

		try {
			// Aktionen auf der DB ausführen
			performJPAActions(entityManager);
		} finally {
			// EntityManager wieder freigeben
			entityManager.close();

			// Am Ende der Applikation
			entityManagerFactory.close();
		}
	}

	private static void performJPAActions(final EntityManager entityManager) {
		try {
			entityManager.getTransaction().begin();

			executeStatements(entityManager);
			performRefresh(entityManager);
			
			entityManager.getTransaction().commit();			
			
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}
	}

	private static void performRefresh(final EntityManager entityManager) {
		final Person michael = entityManager.find(Person.class, 1L);
		System.out.println("AFTER LOAD: " + michael);
		
		// $\mbox{\bfseries REFRESH }$
		michael.setFirstName("MICHAIL");
		michael.setLastName("INDIEN");
		System.out.println("AFTER MODIFIY: " + michael);
		
		// ACHTUNG: Scheinbar harmlos, aber gefährliche Zeile!!!
		//printAllPersons(entityManager); // ACHTUNG: Das triggert Update!!!

		// $\mbox{\bfseries REFRESH }$
		entityManager.refresh(michael);			
		System.out.println("--- AFTER REFRESH: " + michael);
		printAllPersons(entityManager);
	}

	private static void executeStatements(final EntityManager entityManager) {
		final Person michael = new Person("Micha-CRUD", "Inden", LocalDate.of(1971, 2, 7));
		final Person werner = new Person("Werner-CRUD", "Inden", LocalDate.of(1940, 1, 31));
		final Person tim = new Person("Tim-CRUD", "Bötz", LocalDate.of(1971, 3, 27));

		// $\mbox{\bfseries CREATE }$
		entityManager.persist(michael);
		entityManager.persist(werner);
		entityManager.persist(tim);

		// $\mbox{\bfseries READ }$
		final Long id = werner.getId();
		final Person wernerFromDb = entityManager.find(Person.class, id);

		// $\mbox{\bfseries UPDATE }$
		wernerFromDb.setFirstName("Dr. h.c. Werner");

		// $\mbox{\bfseries DELETE }$
		entityManager.remove(tim);

		printAllPersons(entityManager);		
	}

	private static void printAllPersons(final EntityManager entityManager) {
		final String jpql = "SELECT person FROM Person person";
		final TypedQuery<Person> typedQuery = entityManager.createQuery(jpql, Person.class);
		typedQuery.getResultList().forEach(System.out::println);
	}
}
