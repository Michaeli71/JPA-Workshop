package part3_orm_intro.idgeneration;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class CompositeEmbeddableIdEntity             
{
	@EmbeddedId
	CompositeEmbeddableId compositeId;

	String name;
	int additionalValue;
}