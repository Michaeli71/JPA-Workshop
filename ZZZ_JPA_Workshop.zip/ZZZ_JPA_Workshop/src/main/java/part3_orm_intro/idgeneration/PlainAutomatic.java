package part3_orm_intro.idgeneration;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class PlainAutomatic 
{
    @Id @GeneratedValue long id; // still set automatically
}