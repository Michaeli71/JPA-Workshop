package part3_orm_intro.idgeneration;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
@IdClass(CompositeId.class)
public class CompositeIdEntity 
{
	@Id
	int departmentId;
	@Id
	long projectId;

	String name;
	int additionalValue;
}