package part3_orm_intro.idgeneration;

import java.io.Serializable;

public class CompositeId implements Serializable
{
	int departmentId;
	long projectId;
	
	// equals() + hashCode()
}
