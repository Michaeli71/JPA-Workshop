package part3_orm_intro.idgeneration;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ApplicationManagedId 
{
	@Id
	long id; // must be initialized by the application

	public long getId() 
	{
		return id;
	}

	public void setId(long id) 
	{
		this.id = id;
	}
}