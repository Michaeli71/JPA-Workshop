package part3_orm_intro.idgeneration;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.TableGenerator;

@Entity
@TableGenerator(name = "tab", initialValue = 0, allocationSize = 50)
public class EntityWithTableId 
{
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "tab")
	@Id
	long id;
}