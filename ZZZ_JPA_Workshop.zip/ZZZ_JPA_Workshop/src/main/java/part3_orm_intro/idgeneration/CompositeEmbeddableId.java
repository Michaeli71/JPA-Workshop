package part3_orm_intro.idgeneration;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CompositeEmbeddableId implements Serializable
{
	int departmentId;
	long projectId;
	
	// equals() + hashCode()
}
