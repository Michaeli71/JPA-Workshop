package part3_orm_intro.idgeneration;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
// Define a sequence - might also be in another class:
@SequenceGenerator(name = "seq", initialValue = 1, allocationSize = 100)
public class EntityWithSequenceId 
{
	// Use the sequence that is defined above:
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@Id
	long id;
}