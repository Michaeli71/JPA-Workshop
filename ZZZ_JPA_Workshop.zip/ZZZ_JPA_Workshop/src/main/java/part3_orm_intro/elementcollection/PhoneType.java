package part3_orm_intro.elementcollection;

public enum PhoneType {
	Home, Mobile, Work
}