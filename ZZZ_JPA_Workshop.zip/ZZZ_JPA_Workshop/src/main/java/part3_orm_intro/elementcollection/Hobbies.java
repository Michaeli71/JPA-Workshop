package part3_orm_intro.elementcollection;

public enum Hobbies {
	Soccer, Skating, Movies, Programming, Hiking, Music, HomeCinema, Reading, Chess
}