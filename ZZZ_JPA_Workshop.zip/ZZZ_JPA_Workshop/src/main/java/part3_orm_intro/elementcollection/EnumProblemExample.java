package part3_orm_intro.elementcollection;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration einfacher Zugriffe auf die Datenbank mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class EnumProblemExample extends DbBase {
	public static void main(final String[] args) {
		new EnumProblemExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-EC";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
        
		SimpleEmployee simpemp = new SimpleEmployee();
		simpemp.setName("ENUM-PROBLEM-DEMO");
		simpemp.setStatus(Status.REJECTED);
		simpemp.setHobby(Hobbies.Programming);
		entityManager.persist(simpemp);
	}
}
