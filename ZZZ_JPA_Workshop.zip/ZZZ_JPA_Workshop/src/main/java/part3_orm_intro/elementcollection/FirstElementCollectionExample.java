package part3_orm_intro.elementcollection;

import java.util.EnumSet;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration einfacher Zugriffe auf die Datenbank mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class FirstElementCollectionExample extends DbBase {
	public static void main(final String[] args) {
		new FirstElementCollectionExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-EC";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
		SimpleEmployee simpemp = new SimpleEmployee();
		simpemp.setName("ENUM-DEMO");
		entityManager.persist(simpemp);
		
		Employee emp = new Employee();
		emp.setName("Tom");
		emp.getHobbies().addAll(EnumSet.of(Hobbies.HomeCinema, Hobbies.Movies));
		
		Employee emp2 = new Employee();
		emp2.setName("Mike");
		emp2.getHobbies().addAll(EnumSet.of(Hobbies.Chess, Hobbies.Movies, Hobbies.Programming));

		Employee emp3 = new Employee();
		emp3.setName("Tom");

		emp3.getPhoneNumbers().put(PhoneType.Home, "1231231231");
		emp3.getPhoneNumbers().put(PhoneType.Mobile, "01511231231231");

		entityManager.persist(emp);
		entityManager.persist(emp2);
		entityManager.persist(emp3);

		System.out.println(emp);
		System.out.println(emp2);
		System.out.println(emp3);
		
		/*
        final String jpql = "SELECT se FROM SimpleEmployee se";
        final TypedQuery<SimpleEmployee> typedQuery = entityManager.createQuery(jpql, SimpleEmployee.class);
        typedQuery.getResultList().forEach(System.out::println);
        */
	}
}
