package part3_orm_intro.elementcollection;

public enum Status {    
	//FIRED, 
    HIRED, APPROVED, REJECTED;
}