package part3_orm_intro.elementcollection;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity(name = "EC_SimpleEmployee")
public class SimpleEmployee 
{
	@Id
	@GeneratedValue
	private int id;
	private String name;
	private long salary;

	@Enumerated(EnumType.ORDINAL)
	private Status status = Status.HIRED;

	@Enumerated(EnumType.STRING)
	private Hobbies hobby = Hobbies.Chess;

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Hobbies getHobby() {
		return hobby;
	}

	public void setHobby(Hobbies hobby) {
		this.hobby = hobby;
	}
}