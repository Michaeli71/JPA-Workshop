package part3_orm_intro.elementcollection;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MapKeyColumn;
import javax.persistence.MapKeyEnumerated;

@Entity(name = "EC_Employee")
public class Employee 
{
	@Id
	@GeneratedValue
	private int id;
	private String name;
	private long salary;

	private Status status = Status.HIRED;

	@ElementCollection
	private Set<Hobbies> hobbies = new HashSet<>();

	@ElementCollection
	@CollectionTable(name = "EC_EMP_PHONE")
	@MapKeyEnumerated(EnumType.STRING)
	@MapKeyColumn(name = "PHONE_TYPE")
	@Column(name = "PHONE_NUMBER")
	private Map<PhoneType, String> phoneNumbers = new HashMap<>();

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public Map<PhoneType, String> getPhoneNumbers() {
		return phoneNumbers;
	}

	public void setPhoneNumbers(Map<PhoneType, String> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}

	public Set<Hobbies> getHobbies() {
		return hobbies;
	}

	public void setHobbies(Set<Hobbies> hobbies) {
		this.hobbies = hobbies;
	}

}