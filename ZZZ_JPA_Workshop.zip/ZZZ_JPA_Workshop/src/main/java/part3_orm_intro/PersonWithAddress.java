package part3_orm_intro;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Beispielklasse zur Modellierung einer Person mit JPA-Annotations
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
@Entity
@Table(name = "PersonWithEmbeddedAddress")
public class PersonWithAddress implements Serializable {
	@Id
	@GeneratedValue
	private Long id;
	@Column(name = "Vorname")
	private String firstName;
	@Column(name = "Name")
	private String lastName;
	@Column(name = "Geburtstag")
	private LocalDate birthday;

	@Embedded
	private Address address;
	
	
	private PersonWithAddress() {
	}

	public PersonWithAddress(String firstName, String lastName, LocalDate birthday) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.birthday = birthday;
	}

	public Long getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public LocalDate getBirthday() {
		return birthday;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", birthday=" + birthday
				+ "]";
	}
}
