package part3_orm_intro;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 * Hilfsklasse zur Unterstützung der neuen Datentypen auf dem Date And Time API für JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
@Converter(autoApply = false)
public class LocalDateConverter2 implements AttributeConverter<LocalDate, Date>
{
    @Override
    public Date convertToDatabaseColumn(final LocalDate date)
    {
        if (date == null)
        {
            return null;
        }
        final Instant instant = date.atStartOfDay().
                                     atZone(ZoneId.systemDefault()).
                                     toInstant();
        return Date.from(instant);
    }

    @Override
    public LocalDate convertToEntityAttribute(final Date value)
    {
        if (value == null)
        {
            return null;
        }
        final Instant instant = Instant.ofEpochMilli(value.getTime());
        return LocalDateTime.ofInstant(instant, 
                             ZoneId.systemDefault()).toLocalDate();
    }
}