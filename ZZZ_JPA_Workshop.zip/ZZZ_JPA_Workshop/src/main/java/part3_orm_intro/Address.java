package part3_orm_intro;

import javax.persistence.Embeddable;

@Embeddable
public class Address 
{
	String street;
	String city;
	String state;
	String country;
	String zip;
}