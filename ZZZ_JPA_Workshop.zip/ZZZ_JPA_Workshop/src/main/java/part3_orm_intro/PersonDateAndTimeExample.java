package part3_orm_intro;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbetung des neuen Date and Time API mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class PersonDateAndTimeExample extends DbBase
{
    public static void main(final String[] args) throws Exception
    {
    	new PersonDateAndTimeExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-ORM-INTRO";
	}

	@Override
    protected void executeStatements(final EntityManager entityManager)
    {
        // Einfügeoperationen ausführen und das Resultat prüfen
        final Person michael = new Person("Micha-Date", "Inden", LocalDate.of(1971, 2, 7));
        final Person werner = new Person("Werner-Date", "Inden", LocalDate.of(1940, 1, 31));
        final Person tim = new Person("Tim-Date", "Bötz", LocalDate.of(1971, 3, 27));

        entityManager.persist(michael);
        entityManager.persist(werner);
        entityManager.persist(tim);

        final String jpql = "SELECT person FROM Person person";
        final TypedQuery<Person> typedQuery = entityManager.createQuery(jpql, Person.class);
        typedQuery.getResultList().forEach(System.out::println);
    }
}
