package part3_orm_intro;

import java.time.LocalDate;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

/**
 * Hilfsklasse zur Unterstützung der neuen Datentypen auf dem Date And Time API für JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
@Converter(autoApply = true)
public class LocalDateConverter implements 
                                AttributeConverter<LocalDate, String>
{
    @Override
    public String convertToDatabaseColumn(final LocalDate date)
    {
        if (date == null)
            return null;

        return date.toString();
    }

    @Override
    public LocalDate convertToEntityAttribute(final String value)
    {
        if (value == null)
            return null;

        return LocalDate.parse(value);
    }
}