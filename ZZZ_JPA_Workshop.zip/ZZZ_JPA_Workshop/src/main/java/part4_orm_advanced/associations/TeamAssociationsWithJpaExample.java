package part4_orm_advanced.associations;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbeitung von Assoziationen mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2012, 2016 by Michael Inden 
 */
public final class TeamAssociationsWithJpaExample extends DbBase
{
    public static void main(final String[] args)  
    {
    	new TeamAssociationsWithJpaExample().dbAcessAlgorithm();        
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-Associations";
	}
    
	@Override
	protected void executeStatements(final EntityManager entityManager) 
	{
		// Person-Objekte und Adressen-Objekte erzeugen
		final SimplePerson person1 = new SimplePerson("Mike", "Inden", LocalDate.of(1971, 2, 7));
		final SimplePerson person2 = new SimplePerson("Tim", "Bötz", LocalDate.of(71, 3, 27));
		final SimplePerson person3 = new SimplePerson("Lili", "Kurban", LocalDate.of(79, 7, 14));
		
		final Team team1 = new Team("Bowling-People");
		final Team team2 = new Team("Fantasitc Four");
		final Team team3 = new Team("Kino-Wanderfreunde");
		
		// Objekte miteinander verbinden => Assoziation
		team2.getTeamMembers().add(person1);
		team2.getTeamMembers().add(person2);
		team3.getTeamMembers().add(person3);
		// andere Seite auch immer mitpflegen
		person1.setTeam(team2);
		person2.setTeam(team2);
		person3.setTeam(team3);
		
		/* Darauf zielt die Frage ab ...
		team1.getTeamMembers().add(person1);
		team2.getTeamMembers().add(person1);
		team2.getTeamMembers().add(person2);
		team3.getTeamMembers().add(person1);
		team3.getTeamMembers().add(person3);
		*/
		
		// Objekte in Datenbank speichern
		entityManager.persist(person1);
		entityManager.persist(person2);
		entityManager.persist(person3);
		entityManager.persist(team1);
		entityManager.persist(team2);
		entityManager.persist(team3);
		
		// Aus Datenbank auslesen
		final List<Team> teams = 
	            entityManager.createQuery("FROM Team").getResultList();
		teams.forEach(System.out::println);
	
		final List<SimplePerson> persons = 
				                 entityManager.createQuery("FROM SimplePerson").getResultList();
		persons.forEach(System.out::println);
	}
}
