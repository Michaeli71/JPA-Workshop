package part4_orm_advanced.associations.n_plus_1;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Movie {

    @Id
    @GeneratedValue
    Long id;

    String name;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="rental_id")
    Rental belongsToRental;
    
    public Movie()
    {    	
    }
    
	public Movie(String name) {
		this.name = name;
	}

    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Rental getBelongsToRental() {
		return belongsToRental;
	}

	public void setBelongsToRental(Rental belongsToRental) {
		this.belongsToRental = belongsToRental;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Movie [id=" + id + ", name=" + name + "]";
	}
}