package part4_orm_advanced.associations.n_plus_1;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Rental {

	@Id
	@GeneratedValue
	Long id;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "rentals_by_users", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "rental_id"))
	Set<User> renters = new HashSet<>();

	@OneToMany(mappedBy = "belongsToRental", fetch = FetchType.LAZY)
	Set<Movie> movies = new HashSet<>();

	public Rental() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Set<User> getRenters() {
		return renters;
	}

	public void setRenters(Set<User> renters) {
		this.renters = renters;
	}

	public Set<Movie> getMovies() {
		return movies;
	}

	public void setMovies(Set<Movie> movies) {
		this.movies = movies;
	}
}
