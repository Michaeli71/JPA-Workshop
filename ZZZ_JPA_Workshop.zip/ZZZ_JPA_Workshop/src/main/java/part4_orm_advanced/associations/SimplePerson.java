package part4_orm_advanced.associations;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 * Beispielklasse zur Modellierung einer Person mit JPA-Annotations
 * 
 * @author Michael Inden
 * 
 * Copyright 2012 by Michael Inden 
 */
@Entity
public class SimplePerson  
{
    @Id
    @GeneratedValue
    private Long id;

    private String  firstName;
    private String  lastName;
    private LocalDate birthday;
    
    @ManyToOne 
    private Team team;

    
    private SimplePerson()
    {
    }
    
    public SimplePerson(String firstName, String lastName, LocalDate birthday)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = birthday;
    }
    
    public Long getId()
    {
        return id;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public LocalDate getBirthday()
    {
        return birthday;
    }

    public void setFirstName(final String firstName)
    {
        this.firstName = firstName;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public void setLastName(final String lastName)
    {
        this.lastName = lastName;
    }

    public void setBirthday(final LocalDate birthday)
    {
        this.birthday = birthday;
    }

	public Team getTeam() {
		return team;
	}

	public void setTeam(Team team) {
		this.team = team;
	}

	// Achtung: zyklische Navigation SimplePerson -> Team -> SimplePerson
	/*
	@Override
	public String toString() {
		return "SimplePerson [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", birthday="
				+ birthday + ", team=" + team + "]";
	}
	*/
	
	@Override
	public String toString() {
		return "SimplePerson [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", birthday="
				+ birthday + ", team=" + team.getName() + "]";
	}
}
