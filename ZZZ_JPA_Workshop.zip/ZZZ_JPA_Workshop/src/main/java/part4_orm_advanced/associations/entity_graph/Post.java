package part4_orm_advanced.associations.entity_graph;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedSubgraph;
import javax.persistence.OneToMany;



@NamedEntityGraph(
		  name = "post-entity-graph-plain-subject",
		  attributeNodes = {
		    @NamedAttributeNode("subject"),
		  }
		)
@NamedEntityGraph(
		  name = "post-entity-graph",
		  attributeNodes = {
		    @NamedAttributeNode("subject"),
		    @NamedAttributeNode("member"),
		    @NamedAttributeNode("comments"),
		  }
		)
@NamedEntityGraph(
		  name = "post-entity-graph-with-comment-members",
		  attributeNodes = {
		    @NamedAttributeNode("subject"),
		    @NamedAttributeNode("member"),
		    @NamedAttributeNode(value = "comments", subgraph = "comments-subgraph"),
		  },
		  subgraphs = {
		    @NamedSubgraph(
		      name = "comments-subgraph",
		      attributeNodes = {
		        @NamedAttributeNode("member")
		      }
		    )
		  }
		)
@Entity(name = "BLOG_POST")
public class Post {

	@Id
	@GeneratedValue
	private Long id;
	
	private String subject;

	private String additionalInfo;
	private LocalDate timeStamp;
	
	@OneToMany(mappedBy = "post", fetch = FetchType.LAZY)
	private List<Comment> comments = new ArrayList<>();

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn
	private Member member;

	
	public Post()
	{		
	}
	
	public Post(String subject)
	{
		this.subject = subject;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	
	public Comment createComment(String reply)
	{
		Comment comment = new Comment();
		comment.setMember(getMember());
		comment.setPost(this);
		comment.setReply(reply);
		return comment;
	}
}