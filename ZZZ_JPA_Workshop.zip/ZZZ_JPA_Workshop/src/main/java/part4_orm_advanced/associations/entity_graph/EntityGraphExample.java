package part4_orm_advanced.associations.entity_graph;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUtil;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbeitung von Assoziationen mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class EntityGraphExample extends DbBase
{
	public static void main(final String[] args) {
		new EntityGraphExample().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-Associations";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
		Member member1 = new Member("Peter");
		Member member2 = new Member("Michael");
		Member member3 = new Member("James");
		
		// create an address instance
		Post post1 = new Post("Algebra");
		Post post2 = new Post("Algorithms");
		Post post3 = new Post("Java Intro");
		Post post4 = new Post("Java Advanced");

		post3.setMember(member2);
		post4.setMember(member3);
		
		entityManager.persist(member1);
		entityManager.persist(member2);
		entityManager.persist(member3);

		entityManager.persist(post1);
		entityManager.persist(post2);
		entityManager.persist(post3);
		entityManager.persist(post4);

		Comment comment1 = post3.createComment("Very Interessting");
		post3.getComments().add(comment1);

		Comment comment2 = post3.createComment("Happy to see upcoming Java Advanced");
		post3.getComments().add(comment2);
		
		entityManager.persist(comment1);
		entityManager.persist(comment2);
		
		entityManager.flush();
		entityManager.clear();		
		
		Post post = entityManager.find(Post.class, 1L);
		checkAttributesLoaded(post);
		entityManager.clear();		
		
		EntityGraph entityGraph = entityManager.getEntityGraph("post-entity-graph");
		Map<String, Object> properties = new HashMap<>();
		properties.put("javax.persistence.fetchgraph", entityGraph);
		
		Post postEG = entityManager.find(Post.class, 1L, properties);
		checkAttributesLoaded(postEG);
		entityManager.clear();		
		
		EntityGraph entityGraph2 = entityManager.getEntityGraph("post-entity-graph-with-comment-members");
		Map<String, Object> properties2 = new HashMap<>();
		properties2.put("javax.persistence.fetchgraph", entityGraph2);
		
		Post postEG2 = entityManager.find(Post.class, 1L, properties2);
		checkAttributesLoaded(postEG2);
		entityManager.clear();		
		
		EntityGraph entityGraph3 = entityManager.getEntityGraph("post-entity-graph-plain-subject");
		Map<String, Object> properties3 = new HashMap<>();
		properties3.put("javax.persistence.fetchgraph", entityGraph3);
		
		Post postEG3 = entityManager.find(Post.class, 1L, properties3);
		checkAttributesLoaded(postEG3);
		
		entityManager.clear();	
		EntityGraph entityGraph4 = entityManager.createEntityGraph(Post.class);
		entityGraph4.addAttributeNodes("subject");
		entityGraph4.addAttributeNodes("member");
		
		Map<String, Object> properties4 = new HashMap<>();
		properties4.put("javax.persistence.fetchgraph", entityGraph4);
		Post postEG4 = entityManager.find(Post.class, 1L, properties4);
		checkAttributesLoaded(postEG4);
	}
	
	private static void checkAttributesLoaded(Post post) {
		PersistenceUtil util = Persistence.getPersistenceUtil();
		boolean isObjectLoaded = util.isLoaded(post);
		
		// NPE's???
		/*
		boolean isCommentsLoaded = util.isLoaded(post, "comments");
		boolean isMemberLoaded = util.isLoaded(post, "member");

		System.out.println(isObjectLoaded);
		System.out.println(isCommentsLoaded);
		System.out.println(isMemberLoaded);
		*/
		/*
		boolean isCommentsLoaded = Hibernate.isPropertyInitialized(post, "comments");
		System.out.println("comments loaded? " + isCommentsLoaded);
		
		boolean isMemberLoaded = Hibernate.isPropertyInitialized(post, "member");
		System.out.println("member loaded? " + isMemberLoaded);
		*/
	}
}
