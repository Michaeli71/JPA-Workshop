package part4_orm_advanced.associations;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Team {

	@Id
	@GeneratedValue
	private Long id;

	private String name;

	@OneToMany(mappedBy="team")
	private Set<SimplePerson> teamMembers = new HashSet<>();

	public Team() {

	}

	public Team(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Set<SimplePerson> getTeamMembers() {
		return teamMembers;
	}

	public void setTeamMembers(Set<SimplePerson> teamMembers) {
		this.teamMembers = teamMembers;
	}

	// ACHTUNG: zyklische Navigation!
	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + ", teamMembers=" + teamMembers + "]";
	}
}
