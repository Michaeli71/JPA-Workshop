package part4_orm_advanced.associations;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Course 
{
    @Id
    @GeneratedValue
    Long id;

    String name;
    
    @ManyToMany
    @JoinTable(
    		  name = "courses_likes", 
    		  joinColumns = @JoinColumn(name = "course_id"), 
    		  inverseJoinColumns = @JoinColumn(name = "student_id"))
    Set<Student> likedBy = new HashSet<>();

    
    public Course()
    {    	
    }
    
	public Course(String name) {
		this.name = name;
	}

    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Set<Student> getLikedBy() {
		return likedBy;
	}

	public void setLikedBy(Set<Student> likedBy) {
		this.likedBy = likedBy;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Course [id=" + id + ", name=" + name + "]";
	}
}