package part4_orm_advanced.associations;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbeitung von Assoziationen mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class Author_and_Books_Example extends DbBase
{
	public static void main(final String[] args)  {
		new Author_and_Books_Example().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-Associations";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {

		Author author = new Author("Michael");

		Book book1 = new Book("Der Weg zum Java-Profi", "1234");
		Book book2 = new Book("Java Challenge", "12345");

//		author.getPublishedBooks().add(book1);
//		author.getPublishedBooks().add(book2);

		book1.setAuthor(author);
		book2.setAuthor(author);
				
		entityManager.persist(author);
		entityManager.persist(book1);
		entityManager.persist(book2);
	}
}
