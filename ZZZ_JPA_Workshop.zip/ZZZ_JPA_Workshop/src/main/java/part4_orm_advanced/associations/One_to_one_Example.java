package part4_orm_advanced.associations;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbeitung von Assoziationen mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class One_to_one_Example extends DbBase {
	public static void main(final String[] args) throws Exception {
		new One_to_one_Example().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-Associations";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
		// create a user instance
		SimpleUser user = new SimpleUser("John Doe", "john.doe@example.com", "1234abcd");

		// create an address instance
		SimpleAddress address = new SimpleAddress("Lake View 321", "Berlin", "Berlin", "95781", "DE");

		// set child reference
		address.setUser(user);

		// set parent reference
		user.setAddress(address);

		entityManager.persist(user);

		// nicht nötig durch cascade all
		// entityManager.persist(address);

		// -----------------------------

		// create a user instance
		SimpleUser user2 = new SimpleUser("Michael Inden", "michael_inden@hotmail.com", "0815");

		// create an address instance
		SimpleAddress address2 = new SimpleAddress("In der Ey 50", "Zürich", "Switzerland", "8047", "CH");

		// Verknüpfen
		user2.setAddress(address2);
		address2.setUser(user2);
		
		entityManager.persist(address2);

		// nicht nötig durch cascade persist
		// entityManager.persist(user2);
	}
}
