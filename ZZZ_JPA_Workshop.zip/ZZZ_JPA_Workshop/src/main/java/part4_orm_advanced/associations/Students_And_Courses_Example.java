package part4_orm_advanced.associations;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbeitung von Assoziationen mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class Students_And_Courses_Example extends DbBase
{
	public static void main(final String[] args)  {
		new Students_And_Courses_Example().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-Associations";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
		// create a user instance
		Student student1 = new Student("Peter");
		Student student2 = new Student("Michael");
		Student student3 = new Student("James");
		Student student4 = new Student("Tim");
		
		// create an address instance
		Course course1 = new Course("Algebra");
		Course course2 = new Course("Algorithms");
		Course course3 = new Course("Java Intro");
		Course course4 = new Course("Java Advanced");
		Course course5 = new Course("Java For Experts");

		student2.getLikedCourses().add(course3);
		course3.getLikedBy().add(student2);
		student2.getLikedCourses().add(course4);
		course4.getLikedBy().add(student2);
		student2.getLikedCourses().add(course5);
		course5.getLikedBy().add(student2);

		student1.getLikedCourses().add(course3);
		course3.getLikedBy().add(student1);
		student3.getLikedCourses().add(course3);
		course3.getLikedBy().add(student3);
		student4.getLikedCourses().add(course3);
		course3.getLikedBy().add(student4);

		entityManager.persist(student1);
		entityManager.persist(student2);
		entityManager.persist(student3);
		entityManager.persist(student4);

		entityManager.persist(course1);
		entityManager.persist(course2);
		entityManager.persist(course3);
		entityManager.persist(course4);
		entityManager.persist(course5);
		
		Long studentId = student2.getId();
		Long courseId = course3.getId();
		
		// find address for user
		entityManager.flush();
		entityManager.clear();
		
		Student michael = entityManager.find(Student.class, studentId);
		System.out.println("Student: " + michael);
		System.out.println("Liked Course: " + michael.getLikedCourses());

		Course javaIntro = entityManager.find(Course.class, courseId);
		System.out.println("Course: " + javaIntro);
		System.out.println("Liked by: " + javaIntro.getLikedBy());
	}
}
