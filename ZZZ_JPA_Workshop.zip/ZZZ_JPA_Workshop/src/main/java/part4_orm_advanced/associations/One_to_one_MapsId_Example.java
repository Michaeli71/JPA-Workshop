package part4_orm_advanced.associations;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbeitung von Assoziationen mit JPA
 * 
 * @author Michael Inden
 * 
 *         Copyright 2012, 2016 by Michael Inden
 */
public final class One_to_one_MapsId_Example extends DbBase {
	public static void main(final String[] args) throws Exception {
		new One_to_one_MapsId_Example().dbAcessAlgorithm();
	}

	@Override
	protected String getPuName() {
		return "java-profi-PU-Associations";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) {
		// create a user instance
		SimpleUser2 user = new SimpleUser2("John Doe", "john.doe@example.com", "1234abcd");

		// create an address instance
		SimpleAddress2 address = new SimpleAddress2("Lake View 321", "Berlin", "Berlin", "95781", "DE");

		// set child reference
		address.setUser(user);

		entityManager.persist(user);
		long userId = user.getId();
		// das darf man nicht weglassen => andersherum schon!
		entityManager.persist(address);
		
		System.out.println("Address Id: " + address.getId());
		System.out.println("User Id: " + user.getId());
		
		// find address for user
		entityManager.flush();
		entityManager.clear();

		SimpleAddress2 retrievedAddress = entityManager.find(SimpleAddress2.class, userId);
		System.out.println(retrievedAddress);

		
		// create a user instance
		SimpleUser2 user2 = new SimpleUser2("Michael Inden", "michael_inden@hotmail.com", "0815");

		// create an address instance
		SimpleAddress2 address2 = new SimpleAddress2("In der Ey 50", "Zürich", "Switzerland", "8047", "CH");

		// Verknüpfen
		address2.setUser(user2);

		//entityManager.persist(user2);
		entityManager.persist(address2);

		System.out.println("Address Id: " + address2.getId());
		System.out.println("User Id: " + user2.getId());
		Long user2Id = user2.getId();
		
		// find address for user
		entityManager.flush();
		entityManager.clear();

		SimpleAddress2 retrievedAddress2 = entityManager.find(SimpleAddress2.class, user2Id);
		System.out.println(retrievedAddress2);
	}
}
