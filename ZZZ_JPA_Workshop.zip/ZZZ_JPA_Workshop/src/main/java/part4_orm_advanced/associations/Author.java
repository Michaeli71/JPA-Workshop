package part4_orm_advanced.associations;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Author {

	@Id
	@GeneratedValue
	long id;
	
	String name;	
	
	// 1:n
	//@OneToMany(mappedBy = "author")
	//List<Book> publishedBooks = new ArrayList<>();
	//Set<Book> publishedBooks = new HashSet<>();  // => Entity muss equals und hashCode() sauber implementieren!

	public Author() {
	}
	
	public Author(String name) {
		this.name = name;
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public List<Book> getPublishedBooks() {
//		return publishedBooks;
//	}
//
//	public void setPublishedBooks(List<Book> publishedBooks) {
//		this.publishedBooks = publishedBooks;
//	}
}
