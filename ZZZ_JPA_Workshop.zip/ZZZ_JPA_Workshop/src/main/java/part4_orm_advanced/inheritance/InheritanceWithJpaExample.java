package part4_orm_advanced.inheritance;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import utils.DbBase;

/**
 * Beispiel zur Demonstration der Verarbeitung von Vererbung mit JPA
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
public final class InheritanceWithJpaExample extends DbBase
{
    public static void main(final String[] args) throws Exception
    {
        new InheritanceWithJpaExample().dbAcessAlgorithm();
    }

	@Override
	protected String getPuName() {
		return "java-profi-PU-Inheritence";
	}

	@Override
	protected void executeStatements(EntityManager entityManager) 
    {
        // Subklasse Employee erzeugen => das führt automatisch zu 
        // Einträgen in den Tabellen Personen und Mitarbeiter  
        final Employee newEmployee = new Employee("Mr", "Java", new Date(7, 7, 7), 7777, "Entwicklung");

        // Adressen-Objekte erzeugen
        final Address address1 = new Address("Street 1", "Nr 1", 1111, "City 1");
        final Address address2 = new Address("Street 2", "Nr 2", 2222, "City 2");

        // Objekte miteinander verbinden => Assoziation
        newEmployee.setAddresses(Arrays.asList(address1, address2));

        // Mitarbeiter samt Adressen speichern
        entityManager.persist(newEmployee);

        // Employee-Objekt samt Adressen ausgeben
        final List<Employee> employees = entityManager.createQuery("FROM Employee").getResultList();
        employees.forEach(System.out::println);
    }
}
