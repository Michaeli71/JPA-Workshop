package part4_orm_advanced.inheritance.single.initial;

import javax.persistence.Entity;

@Entity
public class Car extends BaseProduct 
{
	private String color;
}