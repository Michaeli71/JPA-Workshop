package part4_orm_advanced.inheritance.single;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("2")
public class Car extends BaseProduct 
{
	private String color;
}