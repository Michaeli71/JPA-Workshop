package part4_orm_advanced.inheritance.single.initial;

import javax.persistence.Entity;

@Entity
public class Book extends BaseProduct 
{
    private String author;
    
    // ...
}