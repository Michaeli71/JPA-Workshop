package part4_orm_advanced.inheritance.single;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("1")
public class Book extends BaseProduct 
{
    private String author;
    
    // ...
}