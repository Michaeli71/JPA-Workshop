package part4_orm_advanced.inheritance.single.initial;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class BaseProduct 
{
    @Id
    private long productId;
    private String name;

    // constructor, getters, setters
}