package part4_orm_advanced.inheritance;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Beispielklasse zur Modellierung einer Adresse mit JPA-Annotations
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
@Entity
@Table(name = "AdressenJPA_Inheritance")
public class Address
{
    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "STRASSE")
    private String  street;

    @Column(name = "HAUSNR")
    private String  no;

    @Column(name = "PLZ")
    private Integer zipcode;

    @Column(name = "STADT")
    private String  city;

    public Address(final String street, final String no, 
                   final Integer zipcode, final String city)
    {
        this.street = street;
        this.no = no;
        this.zipcode = zipcode;
        this.city = city;
    }

    // Für JPA
    private Address()
    {
    }
    
    public long getId()
    {
        return id;
    }

    public void setId(long id)
    {
        this.id = id;
    }

    public String getStreet()
    {
        return street;
    }

    public void setStreet(String street)
    {
        this.street = street;
    }

    public String getNo()
    {
        return no;
    }

    public void setNo(String no)
    {
        this.no = no;
    }

    public Integer getZipcode()
    {
        return zipcode;
    }

    public void setZipcode(Integer zipcode)
    {
        this.zipcode = zipcode;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    @Override
    public String toString()
    {
        return "Address [id=" + id + ", street=" + street + ", no=" + no + ", zipcode=" + zipcode + ", city=" + city
               + "]";
    }
}
