package part4_orm_advanced.inheritance;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Beispielklasse zur Modellierung einer Person mit JPA-Annotations

 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
@Entity
@Table(name = "PersonenJPA_Inheritance")
@Inheritance(strategy=InheritanceType.JOINED)
public class Person implements Serializable
{
    @Id
    @GeneratedValue
    private Long id;

    @Column(name = "Vorname")
    private String  firstName;

    @Column(name = "Name")
    private String  lastName;

    @Column(name = "Geburtstag")
    private Date    birthday;

    @OneToMany(cascade=CascadeType.PERSIST)
    @JoinColumn(name="PersonenID")
    private List<Address> addresses = new ArrayList<>();
    
    protected Person()
    {
    }
    
    public Person(String firstName, String lastName, Date birthday)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = birthday;
    }
    
    public long getId()
    {
        return id;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public Date getBirthday()
    {
        return new Date(birthday.getTime());
    }

    public void setFirstName(final String firstName)
    {
        this.firstName = firstName;
    }

    public void setId(long id)
    {
        this.id = id;
    }

    public void setLastName(final String lastName)
    {
        this.lastName = lastName;
    }

    public void setBirthday(final Date birthday)
    {
        this.birthday = birthday;
    }

    public void setAddresses(final List<Address> addresses)
    {
        this.addresses = addresses;
    }

    public List<Address> getAddresses()
    {
        return addresses;
    }

    @Override
    public String toString()
    {
        return "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", birthday=" + birthday
               + ", addresses=" + addresses + "]";
    }
}
