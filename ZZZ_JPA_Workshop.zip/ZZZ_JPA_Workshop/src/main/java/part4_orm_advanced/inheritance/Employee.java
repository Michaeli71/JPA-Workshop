package part4_orm_advanced.inheritance;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Beispielklasse zur Modellierung eines Mitarbeiters mit JPA-Annotations
 * 
 * @author Michael Inden
 * 
 * Copyright 2016 by Michael Inden 
 */
@Entity
@Table(name = "MitarbeiterJPA_Inheritance")
public class Employee extends Person
{
    @Column(name = "MitarbeiterNr")
    private Integer  employeeNumber;

    @Column(name = "Abteilung")
    private String  workgroup;

    // für JPA
    private Employee()
    {                
    }
    
    public Employee(final String firstName, final String lastName, 
                    final Date birthday, final Integer employeeNumber, final String workgroup)
    {
        super(firstName, lastName, birthday);
        this.employeeNumber = employeeNumber;
        this.workgroup = workgroup;
    }

    public Integer getEmployeeNumber()
    {
        return employeeNumber;
    }

    public void setEmployeeNumber(final Integer employeeNumber)
    {
        this.employeeNumber = employeeNumber;
    }

    public String getWorkgroup()
    {
        return workgroup;
    }

    public void setWorkgroup(final String workgroup)
    {
        this.workgroup = workgroup;
    }

    @Override
    public String toString()
    {
        return "Employee [employeeNumber=" + employeeNumber + ", workgroup=" + workgroup + ", super.toString()=" + super.toString() + "]";
    }
}
