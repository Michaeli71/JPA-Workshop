package part4_orm_advanced.orphan_removal;

import javax.persistence.Entity;

@Entity
class Address 
{
    // ...
}