package part4_orm_advanced.orphan_removal;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "Account")
@Table(name = "Account_OR")
public class AccountEntity implements Serializable
{
    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue
    private Integer           accountId;
    
    @Column(name = "ACC_NO", unique = false, nullable = false, length = 100)
    private String            accountNumber;
 
    @ManyToOne(fetch = FetchType.LAZY)
    private EmployeeEntity employee;
    
	public Integer getAccountId() {
		return accountId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public EmployeeEntity getEmployee() {
		return employee;
	}

	public void setEmployee(EmployeeEntity employee) {
		this.employee = employee;
	}
}