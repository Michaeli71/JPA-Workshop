package part4_orm_advanced.orphan_removal;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
class Employee 
{
    // ...
    //@OneToOne(cascade=CascadeType.REMOVE)
    @OneToOne(orphanRemoval = true)
    private Address address;
    // ...
}

