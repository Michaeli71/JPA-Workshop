package part4_orm_advanced.orphan_removal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import utils.DbBase;

public class OrphanRemovalCascadeExample extends DbBase
{
	public static void main(final String[] args) throws Exception {
		new OrphanRemovalCascadeExample().dbAcessAlgorithm();
	}

    @Override
    protected String getPuName() {
        return "java-profi-PU-OR";
    }

    @Override
    protected void executeStatements(EntityManager entityManager) {
		setupTestData(entityManager);
		
		// Load the employee in another session
		EmployeeEntity employee = entityManager.find(EmployeeEntity.class, 1);
		System.out.println(employee);
				
		// Verify there are 3 accounts
		System.out.println("Step 1 : " + employee.getAccounts().size());

		// Remove an account from first position of collection
		employee.getAccounts().remove(employee.getAccounts().iterator().next());

		// Verify there are 2 accounts in collection
		System.out.println("Step 2 : " + employee.getAccounts().size());
	}

    @Override
    protected void secondAction(EntityManager entityManager) {
		EmployeeEntity employee1 = entityManager.find(EmployeeEntity.class, 1);
		// Verify there are 2 accounts now associated with Employee
		System.out.println("Step 3 : " + employee1.getAccounts().size());

		// Verify there are 2 accounts in Account table
		Query query = entityManager.createQuery("SELECT a from Account a");
		@SuppressWarnings("unchecked")
		List<AccountEntity> accounts = query.getResultList();
		System.out.println("Step 4 : " + accounts.size());
	}

	
    /*
	private static void performJPAActions(final EntityManager entityManager) {


			entityManager.getTransaction().begin();
			executeStatements(entityManager);
			entityManager.flush();
			entityManager.getTransaction().commit();
			
			executeStatementsSeparatly(entityManager);

		} catch (final Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}
	}
*/
    
	
	private static void setupTestData(final EntityManager entityManager)
	{
		// Create Employee
		EmployeeEntity emp = new EmployeeEntity();
		emp.setFirstName("Lokesh");
		emp.setLastName("Gupta");
		entityManager.persist(emp);

		// Create Account 1
		AccountEntity acc1 = new AccountEntity();
		acc1.setAccountNumber("11111111");

		// Create Account 2
		AccountEntity acc2 = new AccountEntity();
		acc2.setAccountNumber("2222222");

		// Create Account 3
		AccountEntity acc3 = new AccountEntity();
		acc3.setAccountNumber("33333333");

		// connect
		emp.getAccounts().add(acc1);
		emp.getAccounts().add(acc2);
		emp.getAccounts().add(acc3);
		acc1.setEmployee(emp);
		acc2.setEmployee(emp);
		acc3.setEmployee(emp);
		/*
		emp.addAccount(acc1);
		emp.addAccount(acc2);
		emp.addAccount(acc3);
		 */
		System.out.println(emp);
	}
}
