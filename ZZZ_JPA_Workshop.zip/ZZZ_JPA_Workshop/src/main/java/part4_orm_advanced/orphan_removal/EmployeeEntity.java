package part4_orm_advanced.orphan_removal;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Employee_OR")
public class EmployeeEntity implements Serializable
{
    @Id
    @Column(name = "ID", unique = true, nullable = false)
    @GeneratedValue
    private Integer           employeeId;
    @Column(name = "FIRST_NAME", unique = false, nullable = false, length = 100)
    private String            firstName;
    @Column(name = "LAST_NAME", unique = false, nullable = false, length = 100)
    private String            lastName;
 
    @OneToMany(cascade=CascadeType.PERSIST, orphanRemoval = true)
    @JoinColumn(name = "account_id")
    private Set<AccountEntity> accountEntities = new HashSet<>();
    
    
	public Integer getEmployeeId() {
		return employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Set<AccountEntity> getAccounts() {
		return accountEntities;
	}

	public void setAccounts(Set<AccountEntity> accountEntities) {
		this.accountEntities = accountEntities;
	}
	
	// besser derartige Methoden anbieten
	public void addAccount(AccountEntity accountEntity) {
		accountEntities.add(accountEntity);
		accountEntity.setEmployee(this);
    }
 
    public void removeAccount(AccountEntity accountEntity) {
    	accountEntities.remove(accountEntity);
    	accountEntity.setEmployee(null);
    }
	
	@Override
	public String toString() {
		return "EmployeeEntity [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", accounts=" + accountEntities + "]";
	}
	
	
}