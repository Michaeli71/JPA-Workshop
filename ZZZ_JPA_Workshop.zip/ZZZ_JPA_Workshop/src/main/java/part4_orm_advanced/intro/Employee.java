package part4_orm_advanced.intro;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
class Employee 
{
    // ...
    @OneToOne(cascade=CascadeType.PERSIST)
    private Address address;
    // ...
}

