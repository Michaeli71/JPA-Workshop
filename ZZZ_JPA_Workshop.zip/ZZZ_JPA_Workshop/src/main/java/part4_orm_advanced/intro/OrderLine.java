package part4_orm_advanced.intro;

import javax.persistence.Entity;

@Entity
class OrderLine 
{
    // ...
}