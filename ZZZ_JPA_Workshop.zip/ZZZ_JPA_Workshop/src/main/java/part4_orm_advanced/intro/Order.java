package part4_orm_advanced.intro;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
class Order 
{
    // ...
    @OneToMany(cascade=CascadeType.REMOVE)
    private List<OrderLine> orderLines;
    // ...
}