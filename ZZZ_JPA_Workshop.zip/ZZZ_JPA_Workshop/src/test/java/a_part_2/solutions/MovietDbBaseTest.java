package a_part_2.solutions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import a_part_2.Movie;

public class MovietDbBaseTest extends AbstractDbBaseTest
{
    // getPuName() kann man nicht überschreiben!!!
    @BeforeAll
    protected static void setUpBeforeClass()   {
        entityManagerFactory = Persistence.createEntityManagerFactory("java-profi-PU-PART-2-SOLUTIONS");
    }
    
    // Test cases
    
    @Test
    protected void testCreateMovies()
    {
        final Movie movie1 = new Movie(1L, "XYZ Gelöste Rätsel", false, LocalDate.of(1977, 5, 18));
        final Movie movie2 = new Movie(2L, "Bames Jond", true, LocalDate.of(2017, 9, 9));

        entityManager.persist(movie1);
        entityManager.persist(movie2);

        final String jpql = "SELECT m FROM Movie m";
        final TypedQuery<Movie> typedQuery = entityManager.createQuery(jpql, Movie.class);
        final List<Movie> resultList = typedQuery.getResultList();
        
        // Variante 1
        assertEquals(2, resultList.size());
        
        // Variante 2: normalerweise besser!!! ACHTUNG: equals / hashCode() !!!
        List<Movie> expected = List.of(movie1, movie2); //, movie2);
        assertEquals(expected, resultList);    
    }	
}
