package a_part_2.solutions;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

public abstract class AbstractDbBaseTest 
{
	// protected static String PU_NAME = "";
	
	static EntityManagerFactory entityManagerFactory;
    EntityManager entityManager;
    
    // getPuName() kann man nicht so leicht überschreiben!!!
//	@BeforeAll
//	protected static void setUpBeforeClass() throws Exception {
//		entityManagerFactory = Persistence.createEntityManagerFactory(PU_NAME);
//	}


	@AfterAll
	protected static void tearDownAfterClass() {
		entityManagerFactory.close();
	}

	@BeforeEach
	protected void setUp()  {
		entityManager = entityManagerFactory.createEntityManager();
		
		 entityManager.getTransaction().begin();
	}

	@AfterEach
	protected void tearDown()  {
		
		entityManager.getTransaction().rollback();
		
		entityManager.close();
	}
}
