package a_part_2.exercises;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MovietDbTest {

	static EntityManagerFactory entityManagerFactory;
    EntityManager entityManager;
    
	@BeforeAll
	protected static void setUpBeforeClass()  {
	}

	@AfterAll
	protected static void tearDownAfterClass()   {
	}

	@BeforeEach
	protected void setUp()   {

	}

	@AfterEach
	protected void tearDown()   {
		

	}
	

	// Test cases
	
	@Test
	protected void testCreateMovies()
	{
	    // TODO  
	}
}
