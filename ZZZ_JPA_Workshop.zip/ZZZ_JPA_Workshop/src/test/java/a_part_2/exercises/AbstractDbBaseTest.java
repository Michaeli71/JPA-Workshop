package a_part_2.exercises;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

public abstract class AbstractDbBaseTest 
{
	static EntityManagerFactory entityManagerFactory;
    EntityManager entityManager;
    
	@BeforeAll
	protected static void setUpBeforeClass()  
	{
		// TODO
	}

	@AfterAll
	protected static void tearDownAfterClass()   {
		// TODO
	}

	@BeforeEach
	protected void setUp()   {
		// TODO
	}

	@AfterEach
	protected void tearDown()   {
		
		// TODO
	}
}
