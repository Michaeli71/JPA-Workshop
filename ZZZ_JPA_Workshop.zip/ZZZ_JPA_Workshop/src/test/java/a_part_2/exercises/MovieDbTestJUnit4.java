package a_part_2.exercises;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class MovieDbTestJUnit4 {

	static EntityManagerFactory entityManagerFactory;
    EntityManager entityManager;
    
	@BeforeClass
	public static void setUpBeforeClass()  {
	}

	@AfterClass
	public static void tearDownAfterClass()   {
	}

	@Before
	public void setUp()   {

	}

	@After
	public void tearDown()  {
		

	}
	

	// Test cases
	
	@Test
	public void testCreateMovies()
	{
	    // TODO  
	}
}
